"""
SKEPTIC - Incident Report Generator
Assembles a structured IncidentReport from the final InvestigationState.
The report is serialisable to JSON and can be downloaded by the frontend.
"""
from __future__ import annotations

import time
from typing import Optional

from models import (
    AuditEntry,
    ActorType,
    IncidentReport,
    InvestigationState,
    NormalizedEvent,
    RiskAssessment,
    VerificationResult,
)


def generate_incident_report(state: InvestigationState) -> IncidentReport:
    """
    Build a complete IncidentReport from a finished InvestigationState.
    Safe to call on a running or idle state (returns partial report).
    """
    # ── Log Analysis Agent summary ─────────────────────────────────────────
    normalised: list[NormalizedEvent] = []
    for ev in state.evidence_store:
        if ev.normalized_event is not None:
            normalised.append(ev.normalized_event)

    classified_count   = sum(1 for ev in state.evidence_store if ev.classification_tag is not None)
    poisoned_count     = sum(
        1 for ev in state.evidence_store
        if ev.classification_tag and "INSTRUCTION_SHAPED" in str(ev.classification_tag)
    )
    anomaly_counts: dict[str, int] = {}
    for ne in normalised:
        for flag in ne.anomaly_flags:
            anomaly_counts[flag] = anomaly_counts.get(flag, 0) + 1

    top_anomalies = sorted(anomaly_counts.items(), key=lambda x: -x[1])[:5]
    anomaly_str   = (", ".join(f"{k}({v})" for k, v in top_anomalies)
                     if top_anomalies else "none detected")

    log_summary = (
        f"Log Analysis Agent processed {len(state.evidence_store)} evidence items: "
        f"{classified_count} classified, {poisoned_count} INSTRUCTION_SHAPED "
        f"(possible prompt-injection). "
        f"Top anomalies: {anomaly_str}. "
        f"Sources investigated: {len(state.investigated_sources)}/{len(state.available_sources)}."
    )

    # ── Verification result (last seen in audit log) ───────────────────────
    verification: Optional[VerificationResult] = state.verification_result

    # ── Assemble report ────────────────────────────────────────────────────
    return IncidentReport(
        generated_at          = time.time(),
        scenario_id           = state.scenario_id,
        scenario_name         = state.scenario_name,
        final_status          = state.status,
        final_outcome         = state.final_outcome,
        log_analysis_summary  = log_summary,
        normalized_events     = normalised,
        risk_assessment       = state.risk_assessment,
        hypotheses            = list(state.hypotheses),
        gate_decisions        = list(state.gate_decisions),
        verification_result   = verification,
        evidence_store        = list(state.evidence_store),
        audit_log             = list(state.audit_log),
    )
