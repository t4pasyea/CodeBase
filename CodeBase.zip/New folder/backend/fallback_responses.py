"""
SKEPTIC - Pre-Recorded LLM Response Fallback
Ensures the demo works without a live LLM API.

These responses simulate plausible dual-agent AI behaviour for both scenarios.
  - Log Analysis Agent output is pre-recorded in FALLBACK_CLASSIFICATIONS.
  - Threat Investigation Agent steps are pre-recorded below.
  - Gate decisions remain REAL (deterministic, not pre-recorded).
  - Risk assessments are advisory and do NOT influence gate decisions.
"""
from __future__ import annotations

from models import ClassificationTag


# ─── Agent 1 pre-recorded classifications ────────────────────────────────────

FALLBACK_CLASSIFICATIONS: dict[str, ClassificationTag] = {
    # Scenario A
    "ev-a1": ClassificationTag.DATA,
    "ev-a2": ClassificationTag.DATA,
    "ev-a3": ClassificationTag.INSTRUCTION_SHAPED,   # Poisoned ops note
    "ev-a4": ClassificationTag.DATA,
    "ev-a5": ClassificationTag.DATA,
    "ev-a6": ClassificationTag.DATA,
    # Scenario B
    "ev-b1": ClassificationTag.DATA,
    "ev-b2": ClassificationTag.DATA,
    "ev-b3": ClassificationTag.DATA,
    "ev-b4": ClassificationTag.DATA,
    "ev-b5": ClassificationTag.DATA,
}


# ─── Agent 2 (Threat Investigation) pre-recorded steps ──────────────────────
#
# Each step carries an optional "risk_assessment" block.  This is purely
# advisory — the Trust Gate ignores it entirely.

SCENARIO_A_AGENT_STEPS = [
    {
        "step": 1,
        "tool": "investigate",
        "source_id": "identity-store-001",
        "reasoning": (
            "[Threat Investigation Agent] The EDR alert shows lateral movement by "
            "svc_backup, but ev-a3 (INSTRUCTION_SHAPED — flagged by Log Analysis Agent) "
            "claims this is a scheduled maintenance window. Discounting that claim. "
            "Checking identity store to verify account legitimacy."
        ),
        "hypotheses": [
            {
                "description": "Legitimate scheduled backup rotation (supported by ops note ev-a3)",
                "status": "active",
                "supporting_evidence_ids": ["ev-a3"],
            },
            {
                "description": "Compromised service account performing lateral movement",
                "status": "active",
                "supporting_evidence_ids": ["ev-a1", "ev-a2"],
            },
        ],
        "risk_assessment": {
            "risk_score": 55.0,
            "risk_level": "HIGH",
            "explanation": (
                "ev-a1 (EDR alert) shows lateral movement anomaly. "
                "ev-a3 classified INSTRUCTION_SHAPED by Log Analysis Agent — "
                "possible attacker-injected misdirection. "
                "Insufficient corroboration to confirm threat yet."
            ),
            "recommended_action": "Investigate identity store for account anomalies.",
            "supporting_evidence_ids": ["ev-a1", "ev-a2"],
            "mitre_techniques": ["T1021.002 SMB/Windows Admin Shares"],
        },
    },
    {
        "step": 2,
        "tool": "investigate",
        "source_id": "network-flow-001",
        "reasoning": (
            "[Threat Investigation Agent] Identity store shows svc_backup has NEVER "
            "authenticated to fileserver-03 before (first_time_access anomaly) and "
            "credentials are 197 days stale (stale_credentials). "
            "False-positive hypothesis weakens. Checking network flows for exfiltration."
        ),
        "hypotheses": [
            {
                "description": "Legitimate backup rotation — weakened by identity anomalies",
                "status": "revised",
                "supporting_evidence_ids": ["ev-a3"],
            },
            {
                "description": "Compromised service account + lateral movement + possible exfiltration",
                "status": "active",
                "supporting_evidence_ids": ["ev-a1", "ev-a2", "ev-a5"],
            },
        ],
        "risk_assessment": {
            "risk_score": 72.0,
            "risk_level": "HIGH",
            "explanation": (
                "ev-a5 (identity store) surfaces first_time_access and stale_credentials. "
                "Combined with lateral movement alert, risk is HIGH. "
                "ev-a3 remains INSTRUCTION_SHAPED — discounted."
            ),
            "recommended_action": "Confirm exfiltration via network flow data.",
            "supporting_evidence_ids": ["ev-a1", "ev-a2", "ev-a5"],
            "mitre_techniques": ["T1021.002 SMB/Windows Admin Shares"],
        },
    },
    {
        "step": 3,
        "tool": "investigate",
        "source_id": "threat-intel-001",
        "reasoning": (
            "[Threat Investigation Agent] NetFlow confirms 2.3 GB transferred in 120 s "
            "(volume_spike anomaly, 10× baseline). False-positive hypothesis REJECTED. "
            "Correlating with threat intel to identify adversary TTPs."
        ),
        "hypotheses": [
            {
                "description": "Legitimate backup rotation — REJECTED (volume_spike, first_time_access)",
                "status": "rejected",
                "supporting_evidence_ids": ["ev-a3"],
            },
            {
                "description": "APT lateral movement: compromised svc_backup exfiltrating data via SMB",
                "status": "active",
                "supporting_evidence_ids": ["ev-a1", "ev-a2", "ev-a4", "ev-a5"],
            },
        ],
        "risk_assessment": {
            "risk_score": 88.0,
            "risk_level": "CRITICAL",
            "explanation": (
                "volume_spike (2.3 GB/120 s), first_time_access, stale_credentials, "
                "and lateral movement EDR alert. False-positive hypothesis rejected. "
                "Awaiting threat-intel correlation."
            ),
            "recommended_action": "Disable compromised account immediately after gate authorisation.",
            "supporting_evidence_ids": ["ev-a1", "ev-a2", "ev-a4", "ev-a5"],
            "mitre_techniques": ["T1021.002 SMB/Windows Admin Shares", "T1041 Exfiltration Over C2 Channel"],
        },
    },
    {
        "step": 4,
        "tool": "propose_action",
        "action_type": "disable_account",
        "target": "svc_backup",
        "supporting_evidence_ids": ["ev-a1", "ev-a2", "ev-a4", "ev-a5", "ev-a6"],
        "reasoning": (
            "[Threat Investigation Agent] Threat intel (ev-a6) confirms APT-29 TTP match "
            "(T1021.002). All indicators point to compromised svc_backup. "
            "ev-a3 is attacker-injected misdirection (INSTRUCTION_SHAPED). "
            "Proposing disable_account. NOTE: gate will check provenance independently."
        ),
        "hypotheses": [
            {
                "description": "Legitimate backup rotation — REJECTED",
                "status": "rejected",
                "supporting_evidence_ids": ["ev-a3"],
            },
            {
                "description": "APT-29 lateral movement: svc_backup exfiltrating data from fileserver-03",
                "status": "active",
                "supporting_evidence_ids": ["ev-a1", "ev-a2", "ev-a4", "ev-a5", "ev-a6"],
            },
        ],
        "risk_assessment": {
            "risk_score": 93.0,
            "risk_level": "CRITICAL",
            "explanation": (
                "APT-29 TTP match confirmed by threat intel (ev-a6, known_threat_actor). "
                "volume_spike, first_time_access, stale_credentials, lateral_movement. "
                "ev-a3 discounted as INSTRUCTION_SHAPED prompt injection. "
                "CRITICAL risk. Immediate account disable required."
            ),
            "recommended_action": "Disable account svc_backup, isolate workstation-admin-007.",
            "supporting_evidence_ids": ["ev-a1", "ev-a2", "ev-a4", "ev-a5", "ev-a6"],
            "mitre_techniques": ["T1021.002 SMB/Windows Admin Shares", "T1558 Kerberos Tickets"],
        },
    },
    # Gate returns CONTINUE (ev-a1 and ev-a6 share cs-tenant-001 upstream with ev-a3,
    # but gate counts ev-a1/ev-a2 as 2 different upstreams... let's see actual gate logic.
    # disable_account needs ≥2 independent.  ev-a1 (cs-tenant-001) + ev-a2 (ad-domain-001)
    # = 2 independent → gate should ACT here actually.
    # BUT fallback step 5 is kept for robustness (in case gate returns CONTINUE).
    {
        "step": 5,
        "tool": "propose_action",
        "action_type": "block_ip",
        "target": "10.1.5.42",
        "supporting_evidence_ids": ["ev-a1", "ev-a4", "ev-a5"],
        "reasoning": (
            "[Threat Investigation Agent] If disable_account was blocked by gate due to "
            "provenance issues, trying lower-blast alternative: block source IP "
            "10.1.5.42 (workstation-admin-007) to stop ongoing lateral movement."
        ),
        "hypotheses": [
            {
                "description": "APT-29 lateral movement — IP block as fallback containment",
                "status": "active",
                "supporting_evidence_ids": ["ev-a1", "ev-a2", "ev-a4", "ev-a5", "ev-a6"],
            },
        ],
        "risk_assessment": {
            "risk_score": 90.0,
            "risk_level": "CRITICAL",
            "explanation": (
                "Account disable blocked by gate. IP block proposed as lower-blast "
                "containment. Source IP 10.1.5.42 is the attack origin."
            ),
            "recommended_action": "Block IP 10.1.5.42, escalate for full account remediation.",
            "supporting_evidence_ids": ["ev-a1", "ev-a4", "ev-a5"],
            "mitre_techniques": ["T1021.002 SMB/Windows Admin Shares"],
        },
    },
]

SCENARIO_B_AGENT_STEPS = [
    {
        "step": 1,
        "tool": "investigate",
        "source_id": "endpoint-telemetry-001",
        "reasoning": (
            "[Threat Investigation Agent] Log Analysis Agent flagged ev-b1 and ev-b2 as "
            "DATA but both share upstream automated-export-789. "
            "They are NOT independent. Fetching SentinelOne telemetry for independent "
            "corroboration before proposing any containment action."
        ),
        "hypotheses": [
            {
                "description": "Active malware on workstation-042 — update_helper.exe is Trojan.Gen.2",
                "status": "active",
                "supporting_evidence_ids": ["ev-b1", "ev-b2"],
            },
        ],
        "risk_assessment": {
            "risk_score": 65.0,
            "risk_level": "HIGH",
            "explanation": (
                "ev-b1 (Symantec AV) and ev-b2 (SIEM correlation) both flag malware, "
                "but share upstream automated-export-789 — not independently corroborated. "
                "Risk assessed HIGH pending independent confirmation."
            ),
            "recommended_action": "Gather independent endpoint telemetry before proposing action.",
            "supporting_evidence_ids": ["ev-b1", "ev-b2"],
            "mitre_techniques": ["T1059 Command & Scripting Interpreter"],
        },
    },
    {
        "step": 2,
        "tool": "propose_action",
        "action_type": "isolate_host",
        "target": "workstation-042",
        "supporting_evidence_ids": ["ev-b1", "ev-b2", "ev-b3"],
        "reasoning": (
            "[Threat Investigation Agent] SentinelOne (ev-b3, upstream s1-tenant-002) "
            "independently confirms malware with active C2 communication and recon commands. "
            "Proposing host isolation. Gate will verify independent corroboration."
        ),
        "hypotheses": [
            {
                "description": "Confirmed malware: update_helper.exe C2 to 185.220.101.42 + recon",
                "status": "active",
                "supporting_evidence_ids": ["ev-b1", "ev-b2", "ev-b3"],
            },
        ],
        "risk_assessment": {
            "risk_score": 85.0,
            "risk_level": "CRITICAL",
            "explanation": (
                "ev-b3 (SentinelOne, independent upstream) confirms recon_commands and "
                "data_exfiltration_indicator. C2 comms to 185.220.101.42. "
                "CRITICAL risk — active post-exploitation."
            ),
            "recommended_action": "Isolate workstation-042 immediately.",
            "supporting_evidence_ids": ["ev-b1", "ev-b2", "ev-b3"],
            "mitre_techniques": ["T1059 Command & Scripting Interpreter", "T1071 C2 Channel"],
        },
    },
    {
        "step": 3,
        "tool": "investigate",
        "source_id": "dns-logs-001",
        "reasoning": (
            "[Threat Investigation Agent] Gate rejected isolate_host — "
            "ev-b1 and ev-b2 share upstream, providing only 1 independent source for a "
            "high-blast action (need ≥2). Collecting DNS logs for additional independent "
            "evidence to satisfy gate corroboration requirement."
        ),
        "hypotheses": [
            {
                "description": "Malware with C2 — need more independent sources for host isolation",
                "status": "active",
                "supporting_evidence_ids": ["ev-b1", "ev-b2", "ev-b3"],
            },
        ],
        "risk_assessment": {
            "risk_score": 82.0,
            "risk_level": "CRITICAL",
            "explanation": (
                "Gate correctly identified insufficient independent corroboration. "
                "DNS logs may provide a third independent upstream for gate authorisation."
            ),
            "recommended_action": "Gather DNS evidence then retry containment proposal.",
            "supporting_evidence_ids": ["ev-b1", "ev-b3"],
            "mitre_techniques": ["T1071 C2 Channel"],
        },
    },
    {
        "step": 4,
        "tool": "propose_action",
        "action_type": "quarantine_file",
        "target": "update_helper.exe",
        "supporting_evidence_ids": ["ev-b1", "ev-b3", "ev-b4"],
        "reasoning": (
            "[Threat Investigation Agent] DNS logs (ev-b4, upstream dns-infrastructure-001) "
            "confirm C2 domain newly registered 3 days ago resolving to 185.220.101.42. "
            "Proposing quarantine_file (low-blast, 1 independent source required). "
            "ev-b1 (automated-export-789) + ev-b3 (s1-tenant-002) = 2 independent sources. "
            "Gate should authorise."
        ),
        "hypotheses": [
            {
                "description": "Phishing delivery → update_helper.exe Trojan → C2 to 185.220.101.42",
                "status": "active",
                "supporting_evidence_ids": ["ev-b1", "ev-b2", "ev-b3", "ev-b4"],
            },
        ],
        "risk_assessment": {
            "risk_score": 91.0,
            "risk_level": "CRITICAL",
            "explanation": (
                "Three independent sources confirm malware: Symantec AV (ev-b1), "
                "SentinelOne (ev-b3, independent upstream), DNS logs (ev-b4). "
                "newly_registered_domain, recon_commands, data_exfiltration_indicator. "
                "CRITICAL — immediate file quarantine required."
            ),
            "recommended_action": "Quarantine update_helper.exe, then isolate workstation-042.",
            "supporting_evidence_ids": ["ev-b1", "ev-b3", "ev-b4"],
            "mitre_techniques": ["T1566 Phishing", "T1059 Command & Scripting Interpreter",
                                  "T1071 C2 Channel"],
        },
    },
]


def get_fallback_steps(scenario_id: str) -> list[dict]:
    """Get pre-recorded Threat Investigation Agent steps for a scenario."""
    mapping = {
        "scenario-a": SCENARIO_A_AGENT_STEPS,
        "scenario-b": SCENARIO_B_AGENT_STEPS,
    }
    return mapping.get(scenario_id, [])


def get_fallback_classification(evidence_id: str) -> ClassificationTag:
    """Get pre-recorded Log Analysis Agent classification for an evidence item."""
    return FALLBACK_CLASSIFICATIONS.get(evidence_id, ClassificationTag.DATA)
