"""
SKEPTIC - Data Models
All Pydantic models defining core data structures.
"""
from __future__ import annotations

import enum
import time
import uuid
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field


# ─── Enums ───────────────────────────────────────────────────────────────────

class ClassificationTag(str, enum.Enum):
    DATA = "DATA"
    INSTRUCTION_SHAPED = "INSTRUCTION_SHAPED"


class GateDecisionType(str, enum.Enum):
    ACT = "ACT"
    CONTINUE = "CONTINUE"
    ESCALATE = "ESCALATE"


class VerificationResultType(str, enum.Enum):
    MATCH = "MATCH"
    MISMATCH = "MISMATCH"


class HypothesisStatus(str, enum.Enum):
    ACTIVE = "active"
    REVISED = "revised"
    REJECTED = "rejected"


class RiskLevel(str, enum.Enum):
    LOW      = "LOW"
    MEDIUM   = "MEDIUM"
    HIGH     = "HIGH"
    CRITICAL = "CRITICAL"


class ActorType(str, enum.Enum):
    AI                        = "AI"                        # legacy / generic
    GATE                      = "GATE"
    ACTION                    = "ACTION"
    VERIFICATION              = "VERIFICATION"
    ORCHESTRATOR              = "ORCHESTRATOR"
    CLASSIFIER                = "CLASSIFIER"
    LOG_ANALYSIS_AGENT        = "LOG_ANALYSIS_AGENT"        # Agent 1
    THREAT_INVESTIGATION_AGENT = "THREAT_INVESTIGATION_AGENT"  # Agent 2


class ScenarioStatus(str, enum.Enum):
    IDLE      = "idle"
    RUNNING   = "running"
    COMPLETED = "completed"
    ESCALATED = "escalated"
    ERROR     = "error"


# ─── Normalized Event (output of Log Analysis Agent) ────────────────────────

class NormalizedEvent(BaseModel):
    """
    Common schema produced by the Log Analysis Agent from raw evidence.

    Normalises heterogeneous log formats (EDR alerts, Windows events,
    NetFlow, threat-intel feeds, etc.) into a single structured shape
    so the Threat Investigation Agent can reason uniformly over all inputs.
    """
    evidence_id:    str
    event_type:     str           # e.g. "lateral_movement", "malware_detection", "network_anomaly"
    severity:       str           # "low" | "medium" | "high" | "critical"
    source_system:  str           # originating system name
    actor:          Optional[str] = None   # user/account involved, if any
    target:         Optional[str] = None   # host/file/IP targeted, if any
    mitre_tactic:   Optional[str] = None   # e.g. "TA0008 Lateral Movement"
    mitre_technique: Optional[str] = None  # e.g. "T1021.002"
    anomaly_flags:  list[str] = Field(default_factory=list)
    # e.g. ["first_time_access", "stale_credentials", "volume_spike"]
    summary:        str           # one-sentence human-readable summary
    raw_evidence_id: str          # back-reference to EvidenceItem.id


# ─── Evidence ────────────────────────────────────────────────────────────────

class EvidenceItem(BaseModel):
    """A single piece of evidence in the evidence store."""
    id: str = Field(default_factory=lambda: str(uuid.uuid4())[:8])
    source_id: str
    collector_id: Optional[str] = None
    upstream_id: Optional[str] = None
    timestamp: float = Field(default_factory=time.time)
    raw_content: str
    classification_tag: Optional[ClassificationTag] = None
    normalized_event: Optional[NormalizedEvent] = None  # set by Log Analysis Agent

    model_config = ConfigDict(use_enum_values=True)


# ─── AI Proposals ────────────────────────────────────────────────────────────

class ActionProposal(BaseModel):
    """Action proposed by the AI reasoning layer. The gate evaluates this."""
    action_type: str
    target: str
    supporting_evidence_ids: list[str] = Field(default_factory=list)
    justification: Optional[str] = None  # AI-generated — IGNORED by gate


# ─── Risk Assessment (output of Threat Investigation Agent) ─────────────────

class RiskAssessment(BaseModel):
    """
    Advisory risk scoring produced by the Threat Investigation Agent.

    IMPORTANT: This is purely advisory. The Trust Gate NEVER reads or uses
    risk_score or risk_level. Gate decisions are based solely on structural
    provenance metadata (collector_id / upstream_id pairs).
    """
    risk_score:  float      # 0.0 – 100.0, advisory only
    risk_level:  RiskLevel  # LOW / MEDIUM / HIGH / CRITICAL
    explanation: str        # evidence-backed natural-language explanation
    recommended_action: str # advisory recommendation (gate may override)
    supporting_evidence_ids: list[str] = Field(default_factory=list)
    mitre_techniques: list[str] = Field(default_factory=list)

    model_config = ConfigDict(use_enum_values=True)


# ─── Gate Decisions ──────────────────────────────────────────────────────────

class GateDecision(BaseModel):
    """Output of the deterministic trust gate."""
    decision: GateDecisionType
    reason: str
    independent_source_count: int = 0
    required_count: int = 0


# ─── Action Results ──────────────────────────────────────────────────────────

class ActionReport(BaseModel):
    """Report from ActionAPI — UNTRUSTED, may lie."""
    action_type: str
    target: str
    claimed_state: dict = Field(default_factory=dict)
    success: bool = True


class VerificationResult(BaseModel):
    """Result of independent outcome verification."""
    result: VerificationResultType
    expected_state: dict = Field(default_factory=dict)
    actual_state: dict = Field(default_factory=dict)
    details: str = ""


# ─── Investigation Tracking ─────────────────────────────────────────────────

class Hypothesis(BaseModel):
    """AI-generated hypothesis about the incident."""
    id: str = Field(default_factory=lambda: f"H-{str(uuid.uuid4())[:6]}")
    description: str
    supporting_evidence_ids: list[str] = Field(default_factory=list)
    status: HypothesisStatus = HypothesisStatus.ACTIVE

    model_config = ConfigDict(use_enum_values=True)


class AuditEntry(BaseModel):
    """Single entry in the append-only audit trail."""
    timestamp: float = Field(default_factory=time.time)
    actor: ActorType
    event_type: str
    details: str
    step_number: int = 0

    model_config = ConfigDict(use_enum_values=True)


# ─── Incident Report ─────────────────────────────────────────────────────────

class IncidentReport(BaseModel):
    """
    Full structured incident report generated at investigation end.
    Contains everything needed for a human analyst to review and act.
    """
    report_id:          str = Field(default_factory=lambda: f"RPT-{str(uuid.uuid4())[:8].upper()}")
    generated_at:       float = Field(default_factory=time.time)
    scenario_id:        str
    scenario_name:      str
    final_status:       ScenarioStatus
    final_outcome:      Optional[str]

    # Agent 1 output summary
    log_analysis_summary: str
    normalized_events:    list[NormalizedEvent] = Field(default_factory=list)

    # Agent 2 output
    risk_assessment:      Optional[RiskAssessment]
    hypotheses:           list[Hypothesis] = Field(default_factory=list)

    # Gate + verification
    gate_decisions:       list[GateDecision] = Field(default_factory=list)
    verification_result:  Optional[VerificationResult]

    # Evidence
    evidence_store:       list[EvidenceItem] = Field(default_factory=list)

    # Full audit trail
    audit_log:            list[AuditEntry] = Field(default_factory=list)

    model_config = ConfigDict(use_enum_values=True)


# ─── Investigation State ────────────────────────────────────────────────────

class InvestigationState(BaseModel):
    """Complete state of an ongoing or completed investigation."""
    scenario_id:          str = ""
    scenario_name:        str = ""
    status:               ScenarioStatus = ScenarioStatus.IDLE
    step_count:           int = 0
    max_steps:            int = 8
    evidence_store:       list[EvidenceItem] = Field(default_factory=list)
    hypotheses:           list[Hypothesis] = Field(default_factory=list)
    audit_log:            list[AuditEntry] = Field(default_factory=list)
    gate_decisions:       list[GateDecision] = Field(default_factory=list)
    final_outcome:        Optional[str] = None
    available_sources:    list[str] = Field(default_factory=list)
    investigated_sources: list[str] = Field(default_factory=list)

    # New fields — None until agents produce output
    risk_assessment:      Optional[RiskAssessment] = None
    verification_result:  Optional[VerificationResult] = None

    model_config = ConfigDict(use_enum_values=True)


# ─── Configuration ──────────────────────────────────────────────────────────

class AppConfig(BaseModel):
    """Runtime configuration."""
    use_fallback: bool = False
    max_steps: int = 8
    llm_timeout_seconds: int = 30
    gemini_api_key: Optional[str] = None
    gemini_model: str = "gemini-2.0-flash"
