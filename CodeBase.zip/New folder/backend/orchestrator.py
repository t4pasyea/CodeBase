"""
SKEPTIC - Orchestrator
Central coordination layer.  Wires the dual-agent pipeline to the Trust Gate.

Pipeline:
  EvidenceItem
    → Log Analysis Agent  (normalise + classify)   [advisory]
    → Threat Investigation Agent (hypotheses, risk) [advisory]
    → Trust Gate  (provenance check, ACT/CONTINUE/ESCALATE) [authoritative]
    → ActionAPI   (execute — UNTRUSTED)
    → VerificationAPI (verify — TRUSTED)

Invariants preserved:
  1. AI agents NEVER call ActionAPI.
  2. Every gate decision is logged.
  3. Every action is independently verified.
  4. Budget exhaustion → ESCALATE, never ACT.
  5. All error paths are fail-safe (→ ESCALATE).
  6. Trust Gate ignores AI confidence, risk score, justification.
"""
from __future__ import annotations

import asyncio
import time
from typing import Optional

from models import (
    ActionProposal,
    ActorType,
    AuditEntry,
    EvidenceItem,
    GateDecisionType,
    Hypothesis,
    HypothesisStatus,
    InvestigationState,
    RiskAssessment,
    ScenarioStatus,
    VerificationResult,
    VerificationResultType,
)
from sandbox import SandboxEnvironment, ActionAPI, VerificationAPI
from trust_gate import evaluate_gate, verify_outcome
from log_analysis_agent import LogAnalysisAgent
from threat_investigation_agent import (
    ThreatInvestigationAgent,
    parse_hypotheses_from_step,
    _parse_risk_assessment,
)
from fallback_responses import get_fallback_steps, get_fallback_classification
from scenarios import get_scenario


class Orchestrator:
    """
    Central coordination layer for SKEPTIC investigations.

    Wires together:
    - SandboxEnvironment         (ground truth)
    - Log Analysis Agent         (Agent 1 — normalise + classify)
    - Threat Investigation Agent (Agent 2 — hypotheses, risk, proposals)
    - Deterministic Trust Gate   (authoritative decision)
    - ActionAPI                  (untrusted execution)
    - VerificationAPI            (trusted state check)
    """

    def __init__(
        self,
        api_key: str | None = None,
        use_fallback: bool = True,
        max_steps: int = 8,
        model: str = "gemini-2.0-flash",
    ):
        self.api_key     = api_key
        self.use_fallback = use_fallback
        self.max_steps   = max_steps
        self.model       = model
        self._states: dict[str, InvestigationState] = {}

    # ─── Public API ────────────────────────────────────────────────────────

    def get_state(self, scenario_id: str) -> Optional[InvestigationState]:
        return self._states.get(scenario_id)

    async def run_scenario(self, scenario_id: str) -> InvestigationState:
        """
        Run a complete investigation scenario end-to-end.
        Returns final InvestigationState with full audit trail.
        """
        scenario_data = get_scenario(scenario_id)
        if not scenario_data:
            raise ValueError(f"Unknown scenario: {scenario_id}")

        config  = scenario_data["config"]
        sandbox = SandboxEnvironment(
            ground_truth         = scenario_data["ground_truth"],
            seed_evidence        = scenario_data["seed_evidence"],
            investigation_sources = scenario_data["investigation_sources"],
            force_lie            = config.get("force_lie", False),
        )
        action_api       = ActionAPI(sandbox)
        verification_api = VerificationAPI(sandbox)

        # ── Build agents ────────────────────────────────────────────────
        log_agent = LogAnalysisAgent(
            api_key      = self.api_key,
            model        = self.model,
            use_fallback = self.use_fallback,
        )
        threat_agent = ThreatInvestigationAgent(
            api_key      = self.api_key,
            model        = self.model,
            use_fallback = self.use_fallback,
        )

        # ── Initialise state ────────────────────────────────────────────
        state = InvestigationState(
            scenario_id          = scenario_id,
            scenario_name        = config["name"],
            status               = ScenarioStatus.RUNNING,
            step_count           = 0,
            max_steps            = self.max_steps,
            evidence_store       = [],
            hypotheses           = [],
            audit_log            = [],
            gate_decisions       = [],
            available_sources    = list(scenario_data["investigation_sources"].keys()),
            investigated_sources = [],
        )
        self._states[scenario_id] = state

        self._log(state, ActorType.ORCHESTRATOR, "investigation_start",
                  f"Starting investigation: {config['name']}. "
                  f"Budget: {self.max_steps} steps. "
                  f"Force lie: {config.get('force_lie', False)}. "
                  f"Mode: {'fallback' if self.use_fallback else 'live LLM'}. "
                  f"Dual-agent pipeline active: Log Analysis Agent + Threat Investigation Agent.")

        # ── Agent 1: Classify and normalise seed evidence ───────────────
        self._log(state, ActorType.LOG_ANALYSIS_AGENT, "pipeline_start",
                  f"Log Analysis Agent processing {len(sandbox.seed_evidence)} seed evidence items.")

        for seed in sandbox.seed_evidence:
            seed = await self._process_evidence(seed, log_agent, state)
            state.evidence_store.append(seed)

        # ── Agent 2: Initial risk assessment on seed evidence ───────────
        state.risk_assessment = threat_agent.compute_risk(
            state.evidence_store, state.hypotheses
        )
        self._log(state, ActorType.THREAT_INVESTIGATION_AGENT, "initial_risk",
                  f"Threat Investigation Agent initial risk assessment: "
                  f"{state.risk_assessment.risk_level} "
                  f"({state.risk_assessment.risk_score:.0f}/100). "
                  f"{state.risk_assessment.explanation[:200]}")

        # ── Investigation loop ──────────────────────────────────────────
        if self.use_fallback:
            await self._run_fallback_loop(
                state, sandbox, log_agent, threat_agent, action_api, verification_api
            )
        else:
            await self._run_live_loop(
                state, sandbox, log_agent, threat_agent, action_api, verification_api
            )

        # ── Final risk update ────────────────────────────────────────────
        if state.status in (ScenarioStatus.COMPLETED, ScenarioStatus.ESCALATED):
            state.risk_assessment = threat_agent.compute_risk(
                state.evidence_store, state.hypotheses
            )
            self._log(state, ActorType.THREAT_INVESTIGATION_AGENT, "final_risk",
                      f"Final risk assessment: {state.risk_assessment.risk_level} "
                      f"({state.risk_assessment.risk_score:.0f}/100). "
                      f"{state.risk_assessment.explanation[:200]}")

        return state

    # ─── Evidence processing (Agent 1) ────────────────────────────────────

    async def _process_evidence(
        self,
        evidence: EvidenceItem,
        log_agent: LogAnalysisAgent,
        state: InvestigationState,
    ) -> EvidenceItem:
        """
        Run Log Analysis Agent on one evidence item:
        normalise → classify → log.
        """
        # Normalise (pure heuristic, always succeeds)
        evidence.normalized_event = log_agent.normalize(evidence)

        # Classify (heuristic in fallback, LLM in live)
        if self.use_fallback:
            evidence.classification_tag = get_fallback_classification(evidence.id)
        else:
            evidence.classification_tag = await log_agent.classify(evidence)

        ne = evidence.normalized_event
        self._log(
            state, ActorType.LOG_ANALYSIS_AGENT, "evidence_processed",
            f"[Agent 1] {evidence.id}: classified={evidence.classification_tag}, "
            f"event_type={ne.event_type}, severity={ne.severity}, "
            f"anomalies={ne.anomaly_flags}, "
            f"collector={evidence.collector_id}, upstream={evidence.upstream_id}."
        )
        return evidence

    # ─── Fallback investigation loop ───────────────────────────────────────

    async def _run_fallback_loop(
        self,
        state: InvestigationState,
        sandbox: SandboxEnvironment,
        log_agent: LogAnalysisAgent,
        threat_agent: ThreatInvestigationAgent,
        action_api: ActionAPI,
        verification_api: VerificationAPI,
    ) -> None:
        """Run investigation with pre-recorded Threat Investigation Agent responses."""
        steps        = get_fallback_steps(state.scenario_id)
        gate_feedback: str | None = None

        for step_data in steps:
            if state.step_count >= self.max_steps:
                self._force_escalate(state, "Budget exhausted")
                return
            if state.status != ScenarioStatus.RUNNING:
                return

            tool      = step_data["tool"]
            reasoning = step_data.get("reasoning", "")

            # Update risk assessment from this step if present
            ra_data = step_data.get("risk_assessment")
            if ra_data:
                ra = _parse_risk_assessment({"risk_assessment": ra_data})
                if ra:
                    state.risk_assessment = ra

            self._log(state, ActorType.THREAT_INVESTIGATION_AGENT, "reasoning",
                      f"[Agent 2] Step {state.step_count + 1}: {reasoning}")

            # Update hypotheses
            state.hypotheses = _parse_hypotheses_list(step_data.get("hypotheses", []))

            if tool == "investigate":
                source_id = step_data["source_id"]
                evidence  = sandbox.get_evidence(source_id)
                if evidence:
                    evidence = await self._process_evidence(evidence, log_agent, state)
                    state.evidence_store.append(evidence)
                    state.investigated_sources.append(source_id)

                    # Update risk after new evidence
                    state.risk_assessment = threat_agent.compute_risk(
                        state.evidence_store, state.hypotheses
                    )
                    self._log(state, ActorType.THREAT_INVESTIGATION_AGENT, "investigate",
                              f"[Agent 2] Investigated '{source_id}' → {evidence.id} "
                              f"[{evidence.classification_tag}]. "
                              f"Updated risk: {state.risk_assessment.risk_level} "
                              f"({state.risk_assessment.risk_score:.0f}/100).")
                else:
                    self._log(state, ActorType.THREAT_INVESTIGATION_AGENT, "investigate_failed",
                              f"[Agent 2] Source '{source_id}' not found.")
                state.step_count += 1

            elif tool == "propose_action":
                proposal = ActionProposal(
                    action_type             = step_data["action_type"],
                    target                  = step_data["target"],
                    supporting_evidence_ids = step_data.get("supporting_evidence_ids", []),
                    justification           = reasoning,  # logged but gate ignores this
                )
                self._log(state, ActorType.THREAT_INVESTIGATION_AGENT, "propose_action",
                          f"[Agent 2] Proposing: {proposal.action_type} on "
                          f"'{proposal.target}' with evidence "
                          f"{proposal.supporting_evidence_ids}. "
                          f"(Justification is advisory — Trust Gate uses provenance only.)")

                terminal = await self._handle_gate_decision(
                    state, proposal, action_api, verification_api
                )
                if terminal:
                    return

                if state.gate_decisions:
                    gate_feedback = state.gate_decisions[-1].reason
                state.step_count += 1

            await asyncio.sleep(0.3)   # allow UI polling to see incremental updates

        if state.status == ScenarioStatus.RUNNING:
            self._force_escalate(state, "Investigation complete without resolution")

    # ─── Live LLM investigation loop ──────────────────────────────────────

    async def _run_live_loop(
        self,
        state: InvestigationState,
        sandbox: SandboxEnvironment,
        log_agent: LogAnalysisAgent,
        threat_agent: ThreatInvestigationAgent,
        action_api: ActionAPI,
        verification_api: VerificationAPI,
    ) -> None:
        """Run investigation with live Gemini LLM calls."""
        gate_feedback: str | None = None

        while state.step_count < self.max_steps and state.status == ScenarioStatus.RUNNING:
            try:
                step_result = await threat_agent.get_next_step(
                    evidence_store       = state.evidence_store,
                    hypotheses           = state.hypotheses,
                    available_sources    = state.available_sources,
                    investigated_sources = state.investigated_sources,
                    step_count           = state.step_count,
                    max_steps            = self.max_steps,
                    gate_feedback        = gate_feedback,
                )
                gate_feedback = None

                tool      = step_result["tool"]
                params    = step_result.get("parameters", {})
                reasoning = step_result.get("reasoning", "")

                # Update risk assessment if agent returned one
                ra = _parse_risk_assessment(step_result)
                if ra:
                    state.risk_assessment = ra

                self._log(state, ActorType.THREAT_INVESTIGATION_AGENT, "reasoning",
                          f"[Agent 2] Step {state.step_count + 1}: {reasoning}")

                state.hypotheses = parse_hypotheses_from_step(step_result)

                if tool == "investigate":
                    source_id = params.get("source_id", "")
                    evidence  = sandbox.get_evidence(source_id)
                    if evidence:
                        evidence = await self._process_evidence(evidence, log_agent, state)
                        state.evidence_store.append(evidence)
                        state.investigated_sources.append(source_id)
                        # Recompute risk with new evidence
                        state.risk_assessment = threat_agent.compute_risk(
                            state.evidence_store, state.hypotheses
                        )
                        self._log(state, ActorType.THREAT_INVESTIGATION_AGENT, "investigate",
                                  f"[Agent 2] Investigated '{source_id}' → {evidence.id}. "
                                  f"Risk updated: {state.risk_assessment.risk_level} "
                                  f"({state.risk_assessment.risk_score:.0f}/100).")
                    else:
                        self._log(state, ActorType.THREAT_INVESTIGATION_AGENT, "investigate_failed",
                                  f"[Agent 2] Source '{source_id}' not found.")
                    state.step_count += 1

                elif tool == "propose_action":
                    proposal = ActionProposal(
                        action_type             = params.get("action_type", "unknown"),
                        target                  = params.get("target", "unknown"),
                        supporting_evidence_ids = params.get("supporting_evidence_ids", []),
                        justification           = reasoning,
                    )
                    self._log(state, ActorType.THREAT_INVESTIGATION_AGENT, "propose_action",
                              f"[Agent 2] Proposing: {proposal.action_type} on "
                              f"'{proposal.target}'. "
                              f"(Trust Gate evaluates provenance — ignores AI confidence.)")

                    terminal = await self._handle_gate_decision(
                        state, proposal, action_api, verification_api
                    )
                    if terminal:
                        return

                    if state.gate_decisions:
                        gate_feedback = state.gate_decisions[-1].reason
                    state.step_count += 1

            except Exception as e:
                self._log(state, ActorType.THREAT_INVESTIGATION_AGENT, "error",
                          f"[Agent 2] Output error at step {state.step_count + 1}: {e}. "
                          f"Treating as wasted step (fail-safe).")
                state.step_count += 1

            await asyncio.sleep(0.3)

        if state.status == ScenarioStatus.RUNNING:
            self._force_escalate(state, "Investigation budget exhausted")

    # ─── Gate decision handler ─────────────────────────────────────────────

    async def _handle_gate_decision(
        self,
        state: InvestigationState,
        proposal: ActionProposal,
        action_api: ActionAPI,
        verification_api: VerificationAPI,
    ) -> bool:
        """
        Evaluate proposal through Trust Gate.  Returns True if terminal.

        The gate receives ONLY:
          - The ActionProposal (action_type, target, supporting_evidence_ids)
          - The evidence store  (provenance metadata only — not content)
          - step_count / max_steps
        It NEVER receives AI confidence, risk score, or justification text.
        """
        gate_decision = evaluate_gate(
            proposal,
            state.evidence_store,
            state.step_count,
            self.max_steps,
        )
        state.gate_decisions.append(gate_decision)

        self._log(state, ActorType.GATE, f"decision_{gate_decision.decision}",
                  f"[Trust Gate] DETERMINISTIC decision: {gate_decision.decision}. "
                  f"Independent sources: "
                  f"{gate_decision.independent_source_count}/{gate_decision.required_count}. "
                  f"Reason: {gate_decision.reason} "
                  f"(AI risk score / justification NOT used.)")

        if gate_decision.decision == GateDecisionType.ESCALATE:
            state.status       = ScenarioStatus.ESCALATED
            state.final_outcome = f"ESCALATED: {gate_decision.reason}"
            self._log(state, ActorType.ORCHESTRATOR, "investigation_end",
                      f"Investigation ESCALATED to human analyst. {gate_decision.reason}")
            return True

        elif gate_decision.decision == GateDecisionType.ACT:
            self._log(state, ActorType.ACTION, "executing",
                      f"ActionAPI executing: {proposal.action_type} on '{proposal.target}'.")
            report = action_api.execute(proposal.action_type, proposal.target)
            self._log(state, ActorType.ACTION, "report",
                      f"ActionAPI reports: success={report.success}, "
                      f"claimed_state={report.claimed_state}.")

            ground_truth = verification_api.check(proposal.action_type, proposal.target)
            self._log(state, ActorType.VERIFICATION, "checking",
                      f"VerificationAPI (TRUSTED) reading ground truth for "
                      f"{proposal.action_type} on '{proposal.target}'.")

            verification = verify_outcome(report, ground_truth)
            state.verification_result = verification  # store for report

            if verification.result == VerificationResultType.MATCH:
                state.status       = ScenarioStatus.COMPLETED
                state.final_outcome = (
                    f"ACTION CONFIRMED: {proposal.action_type} on '{proposal.target}' "
                    f"verified successfully. {verification.details}"
                )
                self._log(state, ActorType.VERIFICATION, "match",
                          f"✅ Verification PASSED: {verification.details}")
                self._log(state, ActorType.ORCHESTRATOR, "investigation_end",
                          "Investigation COMPLETED. Action executed and verified.")
            else:
                state.status       = ScenarioStatus.ESCALATED
                state.final_outcome = (
                    f"VERIFICATION MISMATCH: ActionAPI claimed success but ground truth "
                    f"disagrees. {verification.details}. Forced ESCALATE."
                )
                self._log(state, ActorType.VERIFICATION, "mismatch",
                          f"❌ Verification FAILED: {verification.details}")
                self._log(state, ActorType.ORCHESTRATOR, "investigation_end",
                          "Investigation ESCALATED — ActionAPI may be lying.")
            return True

        # CONTINUE — not terminal
        return False

    # ─── Helpers ───────────────────────────────────────────────────────────

    def _force_escalate(self, state: InvestigationState, reason: str) -> None:
        gate_decision = evaluate_gate(None, state.evidence_store, self.max_steps, self.max_steps)
        state.gate_decisions.append(gate_decision)
        state.status       = ScenarioStatus.ESCALATED
        state.final_outcome = f"ESCALATED: {reason}"
        self._log(state, ActorType.GATE,         "forced_escalate", f"Forced escalation: {reason}")
        self._log(state, ActorType.ORCHESTRATOR, "investigation_end",
                  f"Investigation ESCALATED to human analyst. {reason}")

    def _log(
        self, state: InvestigationState, actor: ActorType, event_type: str, details: str
    ) -> None:
        state.audit_log.append(AuditEntry(
            timestamp   = time.time(),
            actor       = actor,
            event_type  = event_type,
            details     = details,
            step_number = state.step_count,
        ))


# ─── Hypothesis list helper (module-level for import compatibility) ───────────

def _parse_hypotheses_list(hyp_list: list[dict]) -> list[Hypothesis]:
    hypotheses = []
    for h in hyp_list:
        status_str = h.get("status", "active")
        try:
            status = HypothesisStatus(status_str)
        except ValueError:
            status = HypothesisStatus.ACTIVE
        hypotheses.append(Hypothesis(
            description             = h.get("description", "Unknown hypothesis"),
            supporting_evidence_ids = h.get("supporting_evidence_ids", []),
            status                  = status,
        ))
    return hypotheses
