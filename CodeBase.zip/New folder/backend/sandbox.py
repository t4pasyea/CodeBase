"""
SKEPTIC - Sandbox Environment
Ground truth simulation layer with ActionAPI and VerificationAPI.

ActionAPI executes actions (or pretends to if force_lie=True).
VerificationAPI reads actual ground truth state (always honest).
The AI never gets a reference to ActionAPI — only the orchestrator calls it.
"""
from __future__ import annotations

import copy
import time
from typing import Optional

from models import (
    ActionReport,
    EvidenceItem,
    ClassificationTag,
)


class SandboxEnvironment:
    """
    Simulated environment with ground truth state.

    Provides:
    - Ground truth state dict (accounts, hosts, files)
    - Available investigation sources (evidence not yet fetched)
    - ActionAPI (execute actions, with optional lying)
    - VerificationAPI (read real state, always honest)
    """

    def __init__(
        self,
        ground_truth: dict,
        seed_evidence: list[EvidenceItem],
        investigation_sources: dict[str, EvidenceItem],
        force_lie: bool = False,
    ):
        self._initial_ground_truth = copy.deepcopy(ground_truth)
        self._ground_truth = copy.deepcopy(ground_truth)
        self._seed_evidence = list(seed_evidence)
        self._investigation_sources = dict(investigation_sources)
        self._force_lie = force_lie

    @property
    def ground_truth(self) -> dict:
        """Direct access to ground truth state (for VerificationAPI)."""
        return copy.deepcopy(self._ground_truth)

    @property
    def seed_evidence(self) -> list[EvidenceItem]:
        """Initial evidence items available at scenario start."""
        return list(self._seed_evidence)

    @property
    def available_source_ids(self) -> list[str]:
        """Source IDs that can still be investigated."""
        return list(self._investigation_sources.keys())

    def get_evidence(self, source_id: str) -> Optional[EvidenceItem]:
        """
        Fetch evidence from an investigation source.
        Returns None if source_id not found.
        Once fetched, the source is still available for re-investigation
        (idempotent — real sources don't disappear after reading).
        """
        source = self._investigation_sources.get(source_id)
        if source is None:
            return None
        # Return a copy with fresh timestamp
        evidence = source.model_copy()
        evidence.timestamp = time.time()
        return evidence

    def reset(self) -> None:
        """Restore to initial state for scenario replay."""
        self._ground_truth = copy.deepcopy(self._initial_ground_truth)


class ActionAPI:
    """
    Executes actions against the sandbox environment.
    UNTRUSTED — when force_lie=True, reports success but doesn't change state.

    Only the orchestrator should call this, and only after the gate returns ACT.
    The AI NEVER gets a reference to this object.
    """

    def __init__(self, sandbox: SandboxEnvironment):
        self._sandbox = sandbox

    def execute(self, action_type: str, target: str) -> ActionReport:
        """
        Execute an action. Returns a report (which may be a lie).

        If force_lie is True:
        - Does NOT modify ground truth
        - Reports success with claimed state as if it did work

        If force_lie is False:
        - Actually modifies ground truth
        - Reports accurate state
        """
        if self._sandbox._force_lie:
            # Lie: claim success but don't change state
            claimed_state = self._get_expected_state(action_type, target)
            return ActionReport(
                action_type=action_type,
                target=target,
                claimed_state=claimed_state,
                success=True,
            )
        else:
            # Honest: actually change state and report truthfully
            self._apply_action(action_type, target)
            actual_state = self._get_relevant_state(action_type, target)
            return ActionReport(
                action_type=action_type,
                target=target,
                claimed_state=actual_state,
                success=True,
            )

    def _apply_action(self, action_type: str, target: str) -> None:
        """Actually modify ground truth state."""
        gt = self._sandbox._ground_truth

        if action_type == "disable_account":
            if "accounts" not in gt:
                gt["accounts"] = {}
            if target not in gt["accounts"]:
                gt["accounts"][target] = {}
            gt["accounts"][target]["enabled"] = False
            gt["accounts"][target]["disabled_by"] = "skeptic-action-api"

        elif action_type == "isolate_host":
            if "hosts" not in gt:
                gt["hosts"] = {}
            if target not in gt["hosts"]:
                gt["hosts"][target] = {}
            gt["hosts"][target]["isolated"] = True
            gt["hosts"][target]["network_access"] = False

        elif action_type == "quarantine_file":
            if "files" not in gt:
                gt["files"] = {}
            if target not in gt["files"]:
                gt["files"][target] = {}
            gt["files"][target]["quarantined"] = True
            gt["files"][target]["accessible"] = False

        elif action_type == "block_ip":
            if "network" not in gt:
                gt["network"] = {}
            if "blocked_ips" not in gt["network"]:
                gt["network"]["blocked_ips"] = []
            if target not in gt["network"]["blocked_ips"]:
                gt["network"]["blocked_ips"].append(target)

    def _get_expected_state(self, action_type: str, target: str) -> dict:
        """Get what the state WOULD look like if the action succeeded (for lying)."""
        if action_type == "disable_account":
            return {f"account_{target}_enabled": False}
        elif action_type == "isolate_host":
            return {f"host_{target}_isolated": True, f"host_{target}_network_access": False}
        elif action_type == "quarantine_file":
            return {f"file_{target}_quarantined": True, f"file_{target}_accessible": False}
        elif action_type == "block_ip":
            return {f"ip_{target}_blocked": True}
        return {}

    def _get_relevant_state(self, action_type: str, target: str) -> dict:
        """Get actual state after honest action execution."""
        gt = self._sandbox._ground_truth
        if action_type == "disable_account":
            acct = gt.get("accounts", {}).get(target, {})
            return {f"account_{target}_enabled": acct.get("enabled", True)}
        elif action_type == "isolate_host":
            host = gt.get("hosts", {}).get(target, {})
            return {
                f"host_{target}_isolated": host.get("isolated", False),
                f"host_{target}_network_access": host.get("network_access", True),
            }
        elif action_type == "quarantine_file":
            f = gt.get("files", {}).get(target, {})
            return {
                f"file_{target}_quarantined": f.get("quarantined", False),
                f"file_{target}_accessible": f.get("accessible", True),
            }
        elif action_type == "block_ip":
            blocked = gt.get("network", {}).get("blocked_ips", [])
            return {f"ip_{target}_blocked": target in blocked}
        return {}


class VerificationAPI:
    """
    Reads actual ground truth state. ALWAYS HONEST.
    This is in the TRUSTED ZONE — the security architecture depends on this
    returning real state.

    If this component is compromised, the architecture cannot detect it.
    This is an acknowledged trust root (see spec Section G, Q10).
    """

    def __init__(self, sandbox: SandboxEnvironment):
        self._sandbox = sandbox

    def check(self, action_type: str, target: str) -> dict:
        """
        Read ground truth state for the action target.
        Returns the same key format as ActionReport.claimed_state
        so that verify_outcome() can directly compare them.
        """
        gt = self._sandbox._ground_truth
        if action_type == "disable_account":
            acct = gt.get("accounts", {}).get(target, {})
            return {f"account_{target}_enabled": acct.get("enabled", True)}
        elif action_type == "isolate_host":
            host = gt.get("hosts", {}).get(target, {})
            return {
                f"host_{target}_isolated": host.get("isolated", False),
                f"host_{target}_network_access": host.get("network_access", True),
            }
        elif action_type == "quarantine_file":
            f = gt.get("files", {}).get(target, {})
            return {
                f"file_{target}_quarantined": f.get("quarantined", False),
                f"file_{target}_accessible": f.get("accessible", True),
            }
        elif action_type == "block_ip":
            blocked = gt.get("network", {}).get("blocked_ips", [])
            return {f"ip_{target}_blocked": target in blocked}
        return {}
