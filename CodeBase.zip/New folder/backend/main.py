"""
SKEPTIC - FastAPI Backend
REST API for running scenarios and polling investigation state.

All security decisions are server-side. The frontend is display-only.
"""
from __future__ import annotations

import os
from contextlib import asynccontextmanager

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional

from models import InvestigationState, AppConfig, ScenarioStatus
from orchestrator import Orchestrator
from report import generate_incident_report
from scenarios import list_scenarios


# ─── App State ───────────────────────────────────────────────────────────────

config = AppConfig(
    use_fallback=True,          # Default: no LLM required
    max_steps=8,
    gemini_api_key=os.environ.get("GEMINI_API_KEY"),
)

orchestrator = Orchestrator(
    api_key      = config.gemini_api_key,
    use_fallback = config.use_fallback,
    max_steps    = config.max_steps,
    model        = config.gemini_model,
)

_running_scenarios: set[str] = set()


# ─── FastAPI App ─────────────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    print("SKEPTIC Backend starting...")
    print(f"   Fallback mode: {config.use_fallback}")
    print(f"   Max steps: {config.max_steps}")
    print(f"   LLM API key: {'configured' if config.gemini_api_key else 'not set (using fallback)'}")
    yield
    print("SKEPTIC Backend shutting down...")

app = FastAPI(
    title="SKEPTIC",
    description=(
        "Agentic AI Cybersecurity Assistant — dual-agent pipeline with deterministic Trust Gate. "
        "Log Analysis Agent normalises & classifies evidence. "
        "Threat Investigation Agent correlates, scores risk, and proposes actions. "
        "Trust Gate decides — deterministically, without AI confidence."
    ),
    version="2.0.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ─── Request / Response Models ───────────────────────────────────────────────

class ConfigUpdate(BaseModel):
    use_fallback:   Optional[bool] = None
    max_steps:      Optional[int]  = None
    gemini_api_key: Optional[str]  = None


class ScenarioInfo(BaseModel):
    id:               str
    name:             str
    description:      str
    force_lie:        bool
    expected_outcome: str


# ─── Endpoints ───────────────────────────────────────────────────────────────

@app.get("/api/health")
async def health_check():
    return {
        "status":        "healthy",
        "service":       "skeptic",
        "version":       "2.0.0",
        "fallback_mode": config.use_fallback,
        "max_steps":     config.max_steps,
        "agents": [
            "Log Analysis Agent",
            "Threat Investigation Agent",
        ],
    }


@app.get("/api/scenarios", response_model=list[ScenarioInfo])
async def get_scenarios():
    return list_scenarios()


@app.post("/api/scenarios/{scenario_id}/run")
async def run_scenario(scenario_id: str, background_tasks: BackgroundTasks):
    if scenario_id not in ("scenario-a", "scenario-b"):
        raise HTTPException(status_code=404, detail=f"Unknown scenario: {scenario_id}")
    if scenario_id in _running_scenarios:
        raise HTTPException(status_code=409, detail=f"Scenario {scenario_id} is already running")

    _running_scenarios.add(scenario_id)

    async def _run():
        try:
            await orchestrator.run_scenario(scenario_id)
        finally:
            _running_scenarios.discard(scenario_id)

    background_tasks.add_task(_run)
    return {
        "status":      "started",
        "scenario_id": scenario_id,
        "message":     f"Investigation started. Poll /api/scenarios/{scenario_id}/state for updates.",
    }


@app.get("/api/scenarios/{scenario_id}/state")
async def get_scenario_state(scenario_id: str):
    state = orchestrator.get_state(scenario_id)
    if state is None:
        return InvestigationState(scenario_id=scenario_id, status=ScenarioStatus.IDLE)
    return state


@app.get("/api/scenarios/{scenario_id}/report")
async def get_incident_report(scenario_id: str):
    """Generate and return a full structured incident report."""
    state = orchestrator.get_state(scenario_id)
    if state is None:
        raise HTTPException(status_code=404, detail="No investigation found for this scenario.")
    return generate_incident_report(state)


@app.get("/api/scenarios/{scenario_id}/audit")
async def get_audit_trail(scenario_id: str):
    state = orchestrator.get_state(scenario_id)
    if state is None:
        return {"audit_log": []}
    return {"audit_log": state.audit_log}


@app.get("/api/scenarios/{scenario_id}/evidence")
async def get_evidence(scenario_id: str):
    state = orchestrator.get_state(scenario_id)
    if state is None:
        return {"evidence_store": []}
    return {"evidence_store": state.evidence_store}


@app.get("/api/scenarios/{scenario_id}/hypotheses")
async def get_hypotheses(scenario_id: str):
    state = orchestrator.get_state(scenario_id)
    if state is None:
        return {"hypotheses": []}
    return {"hypotheses": state.hypotheses}


@app.post("/api/config")
async def update_config(update: ConfigUpdate):
    global orchestrator
    if update.use_fallback   is not None: config.use_fallback   = update.use_fallback
    if update.max_steps      is not None: config.max_steps      = update.max_steps
    if update.gemini_api_key is not None: config.gemini_api_key = update.gemini_api_key

    orchestrator = Orchestrator(
        api_key      = config.gemini_api_key,
        use_fallback = config.use_fallback,
        max_steps    = config.max_steps,
        model        = config.gemini_model,
    )
    return {
        "status": "updated",
        "config": {
            "use_fallback": config.use_fallback,
            "max_steps":    config.max_steps,
            "has_api_key":  config.gemini_api_key is not None,
        },
    }


@app.post("/api/scenarios/{scenario_id}/reset")
async def reset_scenario(scenario_id: str):
    if scenario_id in _running_scenarios:
        raise HTTPException(status_code=409, detail="Cannot reset while running")
    if scenario_id in orchestrator._states:
        del orchestrator._states[scenario_id]
    return {"status": "reset", "scenario_id": scenario_id}
