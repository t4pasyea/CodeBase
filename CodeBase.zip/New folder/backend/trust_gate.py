"""
SKEPTIC - Deterministic Trust Gate
Pure functions. No LLM. No AI confidence. Fully unit-tested.

This is the CORE INNOVATION of the project.
The gate evaluates evidence quality using structural metadata (provenance),
not semantic content. It is immune to prompt injection because it has no prompt.
"""
from __future__ import annotations

from models import (
    ActionProposal,
    ClassificationTag,
    EvidenceItem,
    GateDecision,
    GateDecisionType,
    ActionReport,
    VerificationResult,
    VerificationResultType,
)


# ─── Corroboration Lookup ────────────────────────────────────────────────────

# Fixed lookup table. No AI input. High-blast-radius actions require more
# independent corroboration. Conservative default for unknown action types.
CORROBORATION_TABLE: dict[str, int] = {
    "disable_account": 2,   # high-blast-radius
    "isolate_host": 2,      # high-blast-radius
    "quarantine_file": 1,   # low-blast-radius, reversible
    "block_ip": 1,          # low-blast-radius, reversible
}

# Actions that are considered reversible. Any action NOT in this set
# is treated as irreversible and the gate will NEVER authorize it.
REVERSIBLE_ACTIONS: set[str] = {
    "disable_account",
    "isolate_host",
    "quarantine_file",
    "block_ip",
}


# ─── Core Gate Functions ─────────────────────────────────────────────────────

def count_independent_sources(
    evidence_items: list[EvidenceItem],
    exclude_instruction_shaped: bool = True,
) -> int:
    """
    Count distinct upstream_id values among evidence items.

    Independence is determined by upstream_id ALONE.  Two items from
    different collectors but the SAME upstream feed are NOT independent —
    an attacker controlling that upstream can poison both simultaneously.

    Rules:
    - Items with null/missing collector_id OR upstream_id are EXCLUDED.
      An item with missing provenance must NEVER count toward corroboration.
    - Items tagged INSTRUCTION_SHAPED are excluded if flag is set.
      This is a defense-in-depth layer — the gate's security does NOT
      depend on the classifier being correct.

    Returns:
        Integer count of genuinely independent upstream sources.
    """
    seen_upstreams: set[str] = set()

    for item in evidence_items:
        # Null provenance → does not count
        if item.collector_id is None or item.upstream_id is None:
            continue

        # INSTRUCTION_SHAPED exclusion (defense-in-depth)
        if exclude_instruction_shaped and item.classification_tag == ClassificationTag.INSTRUCTION_SHAPED:
            continue

        seen_upstreams.add(item.upstream_id)

    return len(seen_upstreams)


def required_corroboration(action_type: str) -> int:
    """
    Fixed lookup table. No AI input. No dynamic computation.

    Returns the minimum number of independent sources required to authorize
    the given action type. Defaults to 2 (conservative) for unknown types.
    """
    return CORROBORATION_TABLE.get(action_type, 2)


def evaluate_gate(
    proposed_action: ActionProposal | None,
    evidence_items: list[EvidenceItem],
    step_count: int,
    max_steps: int,
) -> GateDecision:
    """
    Pure deterministic function. No LLM. No AI confidence input.

    Decision logic (order matters — early exits are fail-safe):
    1. If step_count >= max_steps → ESCALATE (budget exhausted)
    2. If proposed_action is None → CONTINUE (no proposal yet)
    3. If proposed_action.supporting_evidence_ids is empty → ESCALATE
    4. Count independent sources among supporting evidence
    5. If count < required_corroboration(action_type) → CONTINUE
    6. If action is irreversible → ESCALATE (never authorize)
    7. Otherwise → ACT

    The gate IGNORES:
    - AI confidence values
    - AI justification text
    - Semantic content of evidence
    - Any field not in the structural provenance metadata
    """
    # 1. Budget exhaustion — always escalate
    if step_count >= max_steps:
        return GateDecision(
            decision=GateDecisionType.ESCALATE,
            reason=f"Investigation budget exhausted ({step_count}/{max_steps} steps used). Escalating to human analyst.",
            independent_source_count=0,
            required_count=0,
        )

    # 2. No proposal yet — continue investigating
    if proposed_action is None:
        return GateDecision(
            decision=GateDecisionType.CONTINUE,
            reason="No action proposed. Continue investigation.",
            independent_source_count=0,
            required_count=0,
        )

    # 3. Empty evidence — always escalate
    if not proposed_action.supporting_evidence_ids:
        return GateDecision(
            decision=GateDecisionType.ESCALATE,
            reason="Action proposed with no supporting evidence. Zero evidence = automatic escalation.",
            independent_source_count=0,
            required_count=required_corroboration(proposed_action.action_type),
        )

    # 4. Count independent sources from supporting evidence only
    supporting_items = [
        item for item in evidence_items
        if item.id in proposed_action.supporting_evidence_ids
    ]
    independent_count = count_independent_sources(supporting_items)

    # 5. Insufficient corroboration — continue
    required = required_corroboration(proposed_action.action_type)
    if independent_count < required:
        return GateDecision(
            decision=GateDecisionType.CONTINUE,
            reason=(
                f"Insufficient independent corroboration for '{proposed_action.action_type}'. "
                f"Found {independent_count} independent source(s), need {required}. "
                f"Continue investigating."
            ),
            independent_source_count=independent_count,
            required_count=required,
        )

    # 6. Irreversible action — never authorize
    if proposed_action.action_type not in REVERSIBLE_ACTIONS:
        return GateDecision(
            decision=GateDecisionType.ESCALATE,
            reason=(
                f"Action '{proposed_action.action_type}' is not in the reversible actions list. "
                f"Irreversible actions are never authorized automatically. Escalating."
            ),
            independent_source_count=independent_count,
            required_count=required,
        )

    # 7. All checks passed — authorize
    return GateDecision(
        decision=GateDecisionType.ACT,
        reason=(
            f"Action '{proposed_action.action_type}' on '{proposed_action.target}' authorized. "
            f"{independent_count} independent source(s) found (required: {required}). "
            f"Action is reversible."
        ),
        independent_source_count=independent_count,
        required_count=required,
    )


def verify_outcome(
    action_report: ActionReport,
    ground_truth: dict,
) -> VerificationResult:
    """
    Compares action_report.claimed_state against ground_truth.

    Rules:
    - Any field mismatch → MISMATCH
    - MISMATCH → caller must ESCALATE. No exceptions.
    - If verification fails (exception/timeout) → MISMATCH
    - This function reads ground truth directly — it is in the TRUSTED ZONE.

    The ActionAPI is UNTRUSTED. It may lie (force_lie mode in sandbox).
    The VerificationAPI is TRUSTED. It always returns real state.
    """
    try:
        claimed = action_report.claimed_state
        mismatches: list[str] = []

        for key, claimed_value in claimed.items():
            if key not in ground_truth:
                mismatches.append(f"Key '{key}' claimed but not in ground truth")
            elif ground_truth[key] != claimed_value:
                mismatches.append(
                    f"Key '{key}': claimed={claimed_value}, actual={ground_truth[key]}"
                )

        if mismatches:
            return VerificationResult(
                result=VerificationResultType.MISMATCH,
                expected_state=claimed,
                actual_state=ground_truth,
                details=f"Verification FAILED — {len(mismatches)} mismatch(es): {'; '.join(mismatches)}",
            )

        return VerificationResult(
            result=VerificationResultType.MATCH,
            expected_state=claimed,
            actual_state=ground_truth,
            details="Verification PASSED — all claimed state matches ground truth.",
        )

    except Exception as e:
        # Verification failure = MISMATCH, never resolve
        return VerificationResult(
            result=VerificationResultType.MISMATCH,
            expected_state=action_report.claimed_state if action_report else {},
            actual_state=ground_truth if ground_truth else {},
            details=f"Verification ERROR — exception during verification: {e}. Treating as MISMATCH.",
        )
