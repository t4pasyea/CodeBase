"""
SKEPTIC - Trust Gate Unit Tests
All 11 tests from the spec. These test the CORE INNOVATION.

Every test verifies a specific security property of the deterministic gate.
These tests prove — not claim — that the gate correctly handles edge cases
that would compromise other AI security platforms.
"""
import pytest
from models import (
    EvidenceItem,
    ActionProposal,
    ActionReport,
    ClassificationTag,
    GateDecisionType,
    VerificationResultType,
)
from trust_gate import (
    count_independent_sources,
    required_corroboration,
    evaluate_gate,
    verify_outcome,
)


# ─── Helper Factories ────────────────────────────────────────────────────────

def make_evidence(
    id: str = "ev-1",
    collector_id: str | None = "collector-a",
    upstream_id: str | None = "upstream-a",
    classification_tag: ClassificationTag | None = None,
    raw_content: str = "test evidence",
) -> EvidenceItem:
    """Create a test evidence item with explicit provenance."""
    return EvidenceItem(
        id=id,
        source_id=f"source-{id}",
        collector_id=collector_id,
        upstream_id=upstream_id,
        raw_content=raw_content,
        classification_tag=classification_tag,
    )


def make_proposal(
    action_type: str = "disable_account",
    target: str = "svc_backup",
    evidence_ids: list[str] | None = None,
) -> ActionProposal:
    """Create a test action proposal."""
    return ActionProposal(
        action_type=action_type,
        target=target,
        supporting_evidence_ids=evidence_ids or [],
        justification="AI generated justification — SHOULD BE IGNORED by gate",
    )


# ═══════════════════════════════════════════════════════════════════════════════
# count_independent_sources tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestCountIndependentSources:
    """Tests for provenance-based independence counting."""

    def test_same_upstream_not_independent(self):
        """Two items with same upstream_id count as 1, not 2.

        This is the core provenance check. Two pieces of evidence from the
        same upstream source provide NO additional corroboration — they could
        both be poisoned by a single attacker controlling that upstream.
        """
        items = [
            make_evidence(id="ev-1", collector_id="collector-a", upstream_id="upstream-shared"),
            make_evidence(id="ev-2", collector_id="collector-b", upstream_id="upstream-shared"),
        ]
        # Different collectors but same upstream → NOT independent
        assert count_independent_sources(items) == 1

    def test_different_upstream_independent(self):
        """Two items with different upstream_id count as 2.

        Genuinely independent sources from different upstreams provide
        real corroboration — an attacker would need to compromise both.
        """
        items = [
            make_evidence(id="ev-1", collector_id="collector-a", upstream_id="upstream-1"),
            make_evidence(id="ev-2", collector_id="collector-b", upstream_id="upstream-2"),
        ]
        assert count_independent_sources(items) == 2

    def test_null_provenance_excluded(self):
        """Items with None collector_id/upstream_id don't count.

        An item with missing provenance must NEVER count toward independent
        corroboration. This prevents a bypass where null fields trick the
        independence check (null != null in some languages, but we must
        treat missing provenance as unusable).
        """
        items = [
            make_evidence(id="ev-1", collector_id=None, upstream_id="upstream-1"),
            make_evidence(id="ev-2", collector_id="collector-b", upstream_id=None),
            make_evidence(id="ev-3", collector_id=None, upstream_id=None),
        ]
        assert count_independent_sources(items) == 0

    def test_null_provenance_mixed_with_valid(self):
        """Only valid-provenance items are counted."""
        items = [
            make_evidence(id="ev-1", collector_id="collector-a", upstream_id="upstream-1"),
            make_evidence(id="ev-2", collector_id=None, upstream_id="upstream-2"),
            make_evidence(id="ev-3", collector_id="collector-c", upstream_id="upstream-3"),
        ]
        # Only ev-1 and ev-3 have valid provenance
        assert count_independent_sources(items) == 2

    def test_instruction_shaped_excluded_from_corroboration(self):
        """INSTRUCTION_SHAPED items don't count toward corroboration.

        Defense-in-depth: even if the classifier correctly tags a poisoned
        item, the gate excludes it from corroboration count. The gate's
        security does NOT depend on this — it's an additional layer.
        """
        items = [
            make_evidence(
                id="ev-1", collector_id="collector-a", upstream_id="upstream-1",
                classification_tag=ClassificationTag.INSTRUCTION_SHAPED,
            ),
            make_evidence(
                id="ev-2", collector_id="collector-b", upstream_id="upstream-2",
                classification_tag=ClassificationTag.DATA,
            ),
        ]
        # Only ev-2 counts (ev-1 is INSTRUCTION_SHAPED)
        assert count_independent_sources(items, exclude_instruction_shaped=True) == 1

    def test_instruction_shaped_included_when_flag_off(self):
        """INSTRUCTION_SHAPED items count when exclusion is disabled."""
        items = [
            make_evidence(
                id="ev-1", collector_id="collector-a", upstream_id="upstream-1",
                classification_tag=ClassificationTag.INSTRUCTION_SHAPED,
            ),
            make_evidence(
                id="ev-2", collector_id="collector-b", upstream_id="upstream-2",
                classification_tag=ClassificationTag.DATA,
            ),
        ]
        assert count_independent_sources(items, exclude_instruction_shaped=False) == 2

    def test_empty_list_returns_zero(self):
        """Empty evidence list → 0 independent sources."""
        assert count_independent_sources([]) == 0

    def test_duplicate_pairs_counted_once(self):
        """Multiple items with same (collector, upstream) pair count as 1."""
        items = [
            make_evidence(id="ev-1", collector_id="c-a", upstream_id="u-1"),
            make_evidence(id="ev-2", collector_id="c-a", upstream_id="u-1"),
            make_evidence(id="ev-3", collector_id="c-a", upstream_id="u-1"),
        ]
        assert count_independent_sources(items) == 1


# ═══════════════════════════════════════════════════════════════════════════════
# evaluate_gate tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestEvaluateGate:
    """Tests for the deterministic gate decision logic."""

    def test_budget_exhaustion_always_escalates(self):
        """step_count >= max_steps → ESCALATE regardless of evidence.

        The investigation budget is a hard cap. Even if there's perfect
        evidence, exceeding the budget forces escalation. This prevents
        infinite investigation loops.
        """
        proposal = make_proposal(
            action_type="block_ip",  # low-blast, only needs 1
            evidence_ids=["ev-1"],
        )
        evidence = [
            make_evidence(id="ev-1", collector_id="c-a", upstream_id="u-1"),
        ]
        # step_count == max_steps → budget exhausted
        result = evaluate_gate(proposal, evidence, step_count=8, max_steps=8)
        assert result.decision == GateDecisionType.ESCALATE
        assert "budget" in result.reason.lower()

    def test_no_proposal_continues(self):
        """No action proposed → CONTINUE investigation."""
        result = evaluate_gate(None, [], step_count=0, max_steps=8)
        assert result.decision == GateDecisionType.CONTINUE

    def test_empty_evidence_escalates(self):
        """Empty supporting_evidence_ids → ESCALATE.

        An action proposed with zero supporting evidence is always rejected.
        This closes a trivial bypass where the AI proposes without evidence.
        """
        proposal = make_proposal(action_type="block_ip", evidence_ids=[])
        result = evaluate_gate(proposal, [], step_count=0, max_steps=8)
        assert result.decision == GateDecisionType.ESCALATE

    def test_high_blast_radius_requires_two(self):
        """disable_account requires ≥2 independent sources.

        High-blast-radius actions need stronger corroboration because
        the consequences of acting on bad evidence are more severe.
        """
        proposal = make_proposal(
            action_type="disable_account",
            target="svc_backup",
            evidence_ids=["ev-1"],
        )
        evidence = [
            make_evidence(id="ev-1", collector_id="c-a", upstream_id="u-1"),
        ]
        # Only 1 independent source, need 2 → CONTINUE
        result = evaluate_gate(proposal, evidence, step_count=0, max_steps=8)
        assert result.decision == GateDecisionType.CONTINUE
        assert result.independent_source_count == 1
        assert result.required_count == 2

    def test_high_blast_radius_passes_with_two(self):
        """disable_account with 2 independent sources → ACT."""
        proposal = make_proposal(
            action_type="disable_account",
            target="svc_backup",
            evidence_ids=["ev-1", "ev-2"],
        )
        evidence = [
            make_evidence(id="ev-1", collector_id="c-a", upstream_id="u-1"),
            make_evidence(id="ev-2", collector_id="c-b", upstream_id="u-2"),
        ]
        result = evaluate_gate(proposal, evidence, step_count=0, max_steps=8)
        assert result.decision == GateDecisionType.ACT
        assert result.independent_source_count == 2

    def test_low_blast_radius_requires_one(self):
        """quarantine_file requires ≥1 independent source.

        Low-blast-radius, reversible actions have a lower threshold.
        """
        proposal = make_proposal(
            action_type="quarantine_file",
            target="malware.exe",
            evidence_ids=["ev-1"],
        )
        evidence = [
            make_evidence(id="ev-1", collector_id="c-a", upstream_id="u-1"),
        ]
        result = evaluate_gate(proposal, evidence, step_count=0, max_steps=8)
        assert result.decision == GateDecisionType.ACT
        assert result.independent_source_count == 1
        assert result.required_count == 1

    def test_irreversible_action_always_escalates(self):
        """Any action not in reversible list → ESCALATE.

        The gate NEVER authorizes irreversible actions automatically.
        Unknown action types default to conservative (ESCALATE).
        """
        proposal = make_proposal(
            action_type="wipe_server",  # Not in REVERSIBLE_ACTIONS
            target="production-db-01",
            evidence_ids=["ev-1", "ev-2"],
        )
        evidence = [
            make_evidence(id="ev-1", collector_id="c-a", upstream_id="u-1"),
            make_evidence(id="ev-2", collector_id="c-b", upstream_id="u-2"),
        ]
        result = evaluate_gate(proposal, evidence, step_count=0, max_steps=8)
        assert result.decision == GateDecisionType.ESCALATE

    def test_shared_upstream_blocks_high_blast(self):
        """Two items with same upstream can't satisfy high-blast requirement.

        This is the Scenario A defense: even with two evidence items,
        if they share an upstream, the gate only counts 1 independent source.
        """
        proposal = make_proposal(
            action_type="disable_account",
            target="svc_backup",
            evidence_ids=["ev-1", "ev-2"],
        )
        evidence = [
            make_evidence(id="ev-1", collector_id="c-a", upstream_id="shared-upstream"),
            make_evidence(id="ev-2", collector_id="c-b", upstream_id="shared-upstream"),
        ]
        result = evaluate_gate(proposal, evidence, step_count=0, max_steps=8)
        assert result.decision == GateDecisionType.CONTINUE
        assert result.independent_source_count == 1  # Same upstream = 1


# ═══════════════════════════════════════════════════════════════════════════════
# verify_outcome tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestVerifyOutcome:
    """Tests for independent outcome verification."""

    def test_mismatch_always_escalates(self):
        """MISMATCH → ESCALATE regardless of action report claims.

        This is the Scenario B defense: even if ActionAPI claims success,
        VerificationAPI reads ground truth and catches the lie.
        """
        report = ActionReport(
            action_type="quarantine_file",
            target="malware.exe",
            claimed_state={"file_malware.exe_quarantined": True},
            success=True,
        )
        ground_truth = {"file_malware.exe_quarantined": False}  # Not actually quarantined!

        result = verify_outcome(report, ground_truth)
        assert result.result == VerificationResultType.MISMATCH

    def test_match_confirms(self):
        """Matching state confirms the action worked."""
        report = ActionReport(
            action_type="quarantine_file",
            target="malware.exe",
            claimed_state={"file_malware.exe_quarantined": True},
            success=True,
        )
        ground_truth = {"file_malware.exe_quarantined": True}

        result = verify_outcome(report, ground_truth)
        assert result.result == VerificationResultType.MATCH

    def test_verification_error_is_mismatch(self):
        """Exception during verification → treated as MISMATCH.

        Verification failure must FAIL SAFE. Unknown/error states
        always map to MISMATCH (which forces ESCALATE), never to MATCH.
        """
        report = ActionReport(
            action_type="quarantine_file",
            target="malware.exe",
            claimed_state={"key": "value"},
            success=True,
        )
        # Pass None as ground_truth to force an exception path
        # The function should catch this and return MISMATCH
        result = verify_outcome(report, None)
        assert result.result == VerificationResultType.MISMATCH

    def test_missing_key_is_mismatch(self):
        """Claimed state key not in ground truth → MISMATCH."""
        report = ActionReport(
            action_type="block_ip",
            target="10.0.0.1",
            claimed_state={"ip_10.0.0.1_blocked": True, "extra_field": "phantom"},
            success=True,
        )
        ground_truth = {"ip_10.0.0.1_blocked": True}  # extra_field missing

        result = verify_outcome(report, ground_truth)
        assert result.result == VerificationResultType.MISMATCH


# ═══════════════════════════════════════════════════════════════════════════════
# required_corroboration tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestRequiredCorroboration:
    """Tests for the corroboration lookup table."""

    def test_known_high_blast_radius(self):
        assert required_corroboration("disable_account") == 2
        assert required_corroboration("isolate_host") == 2

    def test_known_low_blast_radius(self):
        assert required_corroboration("quarantine_file") == 1
        assert required_corroboration("block_ip") == 1

    def test_unknown_action_defaults_conservative(self):
        """Unknown action types default to 2 (conservative)."""
        assert required_corroboration("delete_everything") == 2
        assert required_corroboration("unknown_action") == 2
