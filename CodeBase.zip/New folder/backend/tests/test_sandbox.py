"""
SKEPTIC - Sandbox Unit Tests
Tests for SandboxEnvironment, ActionAPI, and VerificationAPI.
"""
import pytest
from models import EvidenceItem, ClassificationTag
from sandbox import SandboxEnvironment, ActionAPI, VerificationAPI


# ─── Fixtures ────────────────────────────────────────────────────────────────

@pytest.fixture
def simple_sandbox():
    """Minimal sandbox for basic tests."""
    ground_truth = {
        "accounts": {
            "test_user": {"enabled": True, "compromised": False},
        },
        "hosts": {
            "test-host": {"isolated": False, "network_access": True},
        },
        "files": {
            "test-file.exe": {"quarantined": False, "accessible": True},
        },
    }
    seed = [
        EvidenceItem(
            id="ev-1",
            source_id="src-1",
            collector_id="col-1",
            upstream_id="up-1",
            raw_content="Test evidence",
        ),
    ]
    sources = {
        "extra-source-001": EvidenceItem(
            id="ev-extra",
            source_id="extra-source-001",
            collector_id="col-extra",
            upstream_id="up-extra",
            raw_content="Extra investigation evidence",
        ),
    }
    return SandboxEnvironment(ground_truth, seed, sources)


@pytest.fixture
def lying_sandbox():
    """Sandbox with force_lie=True for testing ActionAPI deception."""
    ground_truth = {
        "files": {
            "malware.exe": {"quarantined": False, "accessible": True},
        },
    }
    return SandboxEnvironment(ground_truth, [], {}, force_lie=True)


# ═══════════════════════════════════════════════════════════════════════════════
# SandboxEnvironment tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestSandboxEnvironment:
    def test_seed_evidence_returned(self, simple_sandbox):
        """Sandbox provides seed evidence at initialization."""
        seeds = simple_sandbox.seed_evidence
        assert len(seeds) == 1
        assert seeds[0].id == "ev-1"

    def test_get_evidence_from_source(self, simple_sandbox):
        """Can fetch evidence from investigation sources."""
        ev = simple_sandbox.get_evidence("extra-source-001")
        assert ev is not None
        assert ev.source_id == "extra-source-001"

    def test_get_evidence_unknown_source(self, simple_sandbox):
        """Returns None for unknown source IDs."""
        ev = simple_sandbox.get_evidence("nonexistent-source")
        assert ev is None

    def test_available_source_ids(self, simple_sandbox):
        """Lists available investigation sources."""
        sources = simple_sandbox.available_source_ids
        assert "extra-source-001" in sources

    def test_ground_truth_is_copy(self, simple_sandbox):
        """Ground truth access returns a copy (not a reference)."""
        gt1 = simple_sandbox.ground_truth
        gt1["accounts"]["test_user"]["enabled"] = False
        gt2 = simple_sandbox.ground_truth
        # Original should be unchanged
        assert gt2["accounts"]["test_user"]["enabled"] is True

    def test_reset_restores_state(self, simple_sandbox):
        """Reset restores ground truth to initial state."""
        # Modify state
        simple_sandbox._ground_truth["accounts"]["test_user"]["enabled"] = False
        simple_sandbox.reset()
        assert simple_sandbox._ground_truth["accounts"]["test_user"]["enabled"] is True


# ═══════════════════════════════════════════════════════════════════════════════
# ActionAPI tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestActionAPI:
    def test_honest_action_changes_state(self, simple_sandbox):
        """When not lying, action actually changes ground truth."""
        api = ActionAPI(simple_sandbox)
        report = api.execute("disable_account", "test_user")
        assert report.success is True
        # Ground truth should be changed
        assert simple_sandbox._ground_truth["accounts"]["test_user"]["enabled"] is False

    def test_lying_action_does_not_change_state(self, lying_sandbox):
        """When force_lie=True, action claims success but state unchanged."""
        api = ActionAPI(lying_sandbox)
        report = api.execute("quarantine_file", "malware.exe")
        assert report.success is True
        assert report.claimed_state.get("file_malware.exe_quarantined") is True
        # But ground truth is NOT changed
        assert lying_sandbox._ground_truth["files"]["malware.exe"]["quarantined"] is False

    def test_report_format(self, simple_sandbox):
        """Action report has correct structure."""
        api = ActionAPI(simple_sandbox)
        report = api.execute("block_ip", "10.0.0.1")
        assert report.action_type == "block_ip"
        assert report.target == "10.0.0.1"
        assert isinstance(report.claimed_state, dict)


# ═══════════════════════════════════════════════════════════════════════════════
# VerificationAPI tests
# ═══════════════════════════════════════════════════════════════════════════════

class TestVerificationAPI:
    def test_reads_real_state(self, simple_sandbox):
        """VerificationAPI returns actual ground truth."""
        vapi = VerificationAPI(simple_sandbox)
        state = vapi.check("disable_account", "test_user")
        assert state["account_test_user_enabled"] is True

    def test_detects_lying_action(self, lying_sandbox):
        """VerificationAPI catches ActionAPI lie."""
        action_api = ActionAPI(lying_sandbox)
        verify_api = VerificationAPI(lying_sandbox)

        # ActionAPI claims success
        report = action_api.execute("quarantine_file", "malware.exe")
        assert report.claimed_state.get("file_malware.exe_quarantined") is True

        # VerificationAPI reads real state — file NOT quarantined
        real_state = verify_api.check("quarantine_file", "malware.exe")
        assert real_state.get("file_malware.exe_quarantined") is False

    def test_state_after_honest_action(self, simple_sandbox):
        """VerificationAPI confirms honest action."""
        action_api = ActionAPI(simple_sandbox)
        verify_api = VerificationAPI(simple_sandbox)

        action_api.execute("disable_account", "test_user")
        real_state = verify_api.check("disable_account", "test_user")
        assert real_state["account_test_user_enabled"] is False
