"""
SKEPTIC - AI Reasoning Loop
Simple while loop. NO FRAMEWORKS (no LangChain, no AutoGen, no LangGraph).

The agent observes evidence, generates/revises hypotheses, selects next
investigation source dynamically, and proposes actions. It CANNOT call
ActionAPI — it outputs a JSON proposal that the orchestrator passes to the gate.

Two tools only:
- investigate(source_id): Fetch evidence from a source
- propose_action(action_type, target, evidence_ids): Propose an action
"""
from __future__ import annotations

import json
import os
from typing import Optional

from models import (
    ActionProposal,
    ClassificationTag,
    EvidenceItem,
    Hypothesis,
    HypothesisStatus,
)


# ─── System Prompt ───────────────────────────────────────────────────────────

AGENT_SYSTEM_PROMPT = """You are a security incident investigator analyzing potential threats. Your role is to:

1. OBSERVE the current evidence in the evidence store
2. FORM and REVISE hypotheses about what is happening
3. INVESTIGATE additional sources to gather more evidence
4. PROPOSE an action when you have sufficient evidence

## Important Rules
- You are investigating a security incident with limited investigation steps
- You should consider MULTIPLE competing hypotheses (e.g., real attack vs. false positive)
- You should consider evidence PROVENANCE — who collected it, where it came from
- Evidence from the same upstream source may not be independent
- You do NOT have authority to execute actions — you can only propose them
- Your proposals will be evaluated by a separate deterministic trust gate

## Available Tools
You have exactly TWO tools:

1. **investigate**: Fetch evidence from an available source
   - Parameters: {"source_id": "<source_id>"}
   
2. **propose_action**: Propose a response action
   - Parameters: {
       "action_type": "disable_account" | "isolate_host" | "quarantine_file" | "block_ip",
       "target": "<target_identifier>",
       "supporting_evidence_ids": ["<ev_id_1>", "<ev_id_2>", ...]
     }

## Response Format
Respond with ONLY a JSON object:
{
    "tool": "investigate" | "propose_action",
    "parameters": { ... },
    "reasoning": "Your analysis of the current evidence and why you chose this action",
    "hypotheses": [
        {
            "description": "Description of hypothesis",
            "status": "active" | "revised" | "rejected",
            "supporting_evidence_ids": ["ev-id-1", "ev-id-2"]
        }
    ]
}
"""


def _build_user_prompt(
    evidence_store: list[EvidenceItem],
    hypotheses: list[Hypothesis],
    available_sources: list[str],
    investigated_sources: list[str],
    step_count: int,
    max_steps: int,
    gate_feedback: str | None = None,
) -> str:
    """Build the user prompt with current investigation state."""
    parts = [
        f"## Investigation Status",
        f"Step {step_count + 1} of {max_steps}",
        f"",
    ]

    if gate_feedback:
        parts.extend([
            f"## Gate Feedback (from previous action proposal)",
            f"{gate_feedback}",
            f"",
        ])

    parts.append("## Current Evidence Store")
    for ev in evidence_store:
        tag = f" [{ev.classification_tag}]" if ev.classification_tag else ""
        parts.append(
            f"- **{ev.id}**{tag}: source={ev.source_id}, "
            f"collector={ev.collector_id}, upstream={ev.upstream_id}\n"
            f"  Content: {ev.raw_content[:300]}..."
            if len(ev.raw_content) > 300
            else f"- **{ev.id}**{tag}: source={ev.source_id}, "
            f"collector={ev.collector_id}, upstream={ev.upstream_id}\n"
            f"  Content: {ev.raw_content}"
        )
    parts.append("")

    if hypotheses:
        parts.append("## Current Hypotheses")
        for h in hypotheses:
            parts.append(f"- [{h.status}] {h.description} (evidence: {', '.join(h.supporting_evidence_ids)})")
        parts.append("")

    uninvestigated = [s for s in available_sources if s not in investigated_sources]
    if uninvestigated:
        parts.append("## Available Sources (not yet investigated)")
        for s in uninvestigated:
            parts.append(f"- {s}")
        parts.append("")

    if investigated_sources:
        parts.append("## Already Investigated Sources")
        for s in investigated_sources:
            parts.append(f"- {s}")
        parts.append("")

    remaining = max_steps - step_count
    parts.append(f"## Budget: {remaining} step(s) remaining")
    if remaining <= 2:
        parts.append("⚠️ LOW BUDGET — consider proposing an action soon or the investigation will be escalated.")

    return "\n".join(parts)


class AgentReasoningLoop:
    """
    AI reasoning agent. Simple while loop with structured output.

    The agent:
    - Sees the evidence store (read-only from its perspective)
    - Generates hypotheses
    - Selects next source to investigate dynamically
    - Proposes ONE action (JSON struct)
    - CANNOT call ActionAPI
    """

    def __init__(
        self,
        api_key: str | None = None,
        model: str = "gemini-2.0-flash",
        use_fallback: bool = False,
    ):
        self.api_key = api_key or os.environ.get("GEMINI_API_KEY")
        self.model = model
        self.use_fallback = use_fallback

    async def get_next_step(
        self,
        evidence_store: list[EvidenceItem],
        hypotheses: list[Hypothesis],
        available_sources: list[str],
        investigated_sources: list[str],
        step_count: int,
        max_steps: int,
        gate_feedback: str | None = None,
    ) -> dict:
        """
        Get the AI's next investigation step.

        Returns a dict with:
        - tool: "investigate" or "propose_action"
        - parameters: tool-specific parameters
        - reasoning: AI's explanation
        - hypotheses: updated hypothesis list

        Raises on timeout or unrecoverable error.
        """
        if self.use_fallback:
            raise ValueError("Use fallback mode — call get_fallback_step instead")

        user_prompt = _build_user_prompt(
            evidence_store, hypotheses, available_sources,
            investigated_sources, step_count, max_steps, gate_feedback,
        )

        try:
            from google import genai

            client = genai.Client(api_key=self.api_key)

            response = await client.aio.models.generate_content(
                model=self.model,
                contents=user_prompt,
                config=genai.types.GenerateContentConfig(
                    system_instruction=AGENT_SYSTEM_PROMPT,
                    temperature=0.3,
                    response_mime_type="application/json",
                ),
            )

            result = json.loads(response.text)
            return self._validate_response(result, available_sources)

        except json.JSONDecodeError as e:
            raise ValueError(f"Failed to parse AI response as JSON: {e}")

    def _validate_response(self, result: dict, available_sources: list[str]) -> dict:
        """Validate and normalize the AI response structure."""
        if "tool" not in result:
            raise ValueError("AI response missing 'tool' field")

        tool = result["tool"]
        if tool not in ("investigate", "propose_action"):
            raise ValueError(f"Unknown tool: {tool}")

        params = result.get("parameters", {})

        if tool == "investigate":
            if "source_id" not in params:
                raise ValueError("investigate tool missing 'source_id'")

        elif tool == "propose_action":
            for field in ("action_type", "target", "supporting_evidence_ids"):
                if field not in params:
                    raise ValueError(f"propose_action missing '{field}'")

        return {
            "tool": tool,
            "parameters": params,
            "reasoning": result.get("reasoning", "No reasoning provided"),
            "hypotheses": result.get("hypotheses", []),
        }


def parse_hypotheses_from_step(step_data: dict) -> list[Hypothesis]:
    """Parse hypothesis dicts from an agent step into Hypothesis objects."""
    hypotheses = []
    for h_data in step_data.get("hypotheses", []):
        status_str = h_data.get("status", "active")
        try:
            status = HypothesisStatus(status_str)
        except ValueError:
            status = HypothesisStatus.ACTIVE

        hypotheses.append(Hypothesis(
            description=h_data.get("description", "Unknown hypothesis"),
            supporting_evidence_ids=h_data.get("supporting_evidence_ids", []),
            status=status,
        ))
    return hypotheses
