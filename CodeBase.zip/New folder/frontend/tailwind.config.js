/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        // Dark SOC terminal palette
        surface: {
          50:  '#f0f4f8',
          100: '#1a1d2e',
          200: '#141624',
          300: '#0f111a',
          400: '#0a0c14',
          500: '#06080f',
        },
        brand: {
          DEFAULT: '#00d4ff',
          dim:     '#0099bb',
          glow:    '#00d4ff33',
        },
        threat: {
          critical: '#ff3b3b',
          high:     '#ff6b35',
          medium:   '#ffa500',
          low:      '#38d9a9',
          info:     '#74c0fc',
        },
        gate: {
          act:      '#22c55e',
          continue: '#f59e0b',
          escalate: '#ef4444',
        },
        evidence: {
          data:        '#60a5fa',
          instruction: '#f87171',
        },
        hyp: {
          active:   '#a78bfa',
          revised:  '#fbbf24',
          rejected: '#6b7280',
        },
        actor: {
          ai:           '#818cf8',
          gate:         '#f472b6',
          action:       '#fb923c',
          verification: '#34d399',
          orchestrator: '#64748b',
          classifier:   '#38bdf8',
        },
      },
      fontFamily: {
        mono: ['"JetBrains Mono"', '"Fira Code"', 'Menlo', 'monospace'],
        sans: ['"Inter"', 'system-ui', 'sans-serif'],
      },
      animation: {
        'pulse-slow':  'pulse 3s cubic-bezier(0.4,0,0.6,1) infinite',
        'spin-slow':   'spin 3s linear infinite',
        'fade-in':     'fadeIn 0.3s ease-in-out',
        'slide-up':    'slideUp 0.3s ease-out',
        'glow-pulse':  'glowPulse 2s ease-in-out infinite',
      },
      keyframes: {
        fadeIn:    { from: { opacity: '0' },                  to: { opacity: '1' } },
        slideUp:   { from: { opacity: '0', transform: 'translateY(8px)' }, to: { opacity: '1', transform: 'translateY(0)' } },
        glowPulse: { '0%,100%': { boxShadow: '0 0 4px #00d4ff44' }, '50%': { boxShadow: '0 0 16px #00d4ff88' } },
      },
      boxShadow: {
        'glow-brand':    '0 0 12px #00d4ff44',
        'glow-act':      '0 0 12px #22c55e44',
        'glow-escalate': '0 0 12px #ef444444',
        'panel':         '0 2px 12px rgba(0,0,0,0.5)',
      },
    },
  },
  plugins: [],
}
