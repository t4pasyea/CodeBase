import { useCallback, useEffect, useRef, useState } from 'react'
import {
  getHealth,
  getScenarios,
  getScenarioState,
  runScenario,
  resetScenario,
  ApiError,
} from '../api/client'
import type { HealthStatus, InvestigationState, ScenarioInfo } from '../api/types'

const POLL_INTERVAL_MS  = 1500   // while running
const IDLE_INTERVAL_MS  = 8000   // when idle / completed

export function useInvestigation() {
  const [health, setHealth]               = useState<HealthStatus | null>(null)
  const [backendOnline, setBackendOnline] = useState(false)
  const [scenarios, setScenarios]         = useState<ScenarioInfo[]>([])
  const [states, setStates]               = useState<Record<string, InvestigationState>>({})
  const [activeScenarioId, setActiveScenarioId] = useState<string | null>(null)
  const [loadingId, setLoadingId]         = useState<string | null>(null)
  const [error, setError]                 = useState<string | null>(null)

  const pollingRef = useRef<ReturnType<typeof setInterval> | null>(null)

  // ─── Health + Scenarios (initial load) ──────────────────────────────────

  const refreshHealthAndScenarios = useCallback(async () => {
    try {
      const [h, s] = await Promise.all([getHealth(), getScenarios()])
      setHealth(h)
      setScenarios(s)
      setBackendOnline(true)
      setError(null)
    } catch {
      setBackendOnline(false)
      setError('Cannot reach backend — is it running on localhost:8000?')
    }
  }, [])

  // ─── Poll a single scenario ──────────────────────────────────────────────

  const pollScenario = useCallback(async (id: string) => {
    try {
      const state = await getScenarioState(id)
      setStates((prev) => ({ ...prev, [id]: state }))
      return state
    } catch {
      return null
    }
  }, [])

  // ─── Polling loop ────────────────────────────────────────────────────────

  const startPolling = useCallback((id: string) => {
    if (pollingRef.current) clearInterval(pollingRef.current)

    const tick = async () => {
      const state = await pollScenario(id)
      if (!state) return

      // When no longer running, switch to slow poll
      if (state.status !== 'running') {
        if (pollingRef.current) clearInterval(pollingRef.current)
        pollingRef.current = setInterval(() => pollScenario(id), IDLE_INTERVAL_MS)
      }
    }

    tick()
    pollingRef.current = setInterval(tick, POLL_INTERVAL_MS)
  }, [pollScenario])

  useEffect(() => {
    return () => {
      if (pollingRef.current) clearInterval(pollingRef.current)
    }
  }, [])

  // ─── Initial load ────────────────────────────────────────────────────────

  useEffect(() => {
    refreshHealthAndScenarios()
  }, [refreshHealthAndScenarios])

  // ─── Actions ─────────────────────────────────────────────────────────────

  const handleRun = useCallback(async (id: string) => {
    setLoadingId(id)
    setActiveScenarioId(id)
    setError(null)
    try {
      await runScenario(id)
      startPolling(id)
    } catch (e) {
      if (e instanceof ApiError && e.status === 409) {
        // Already running — just start polling
        startPolling(id)
      } else {
        setError(e instanceof Error ? e.message : String(e))
      }
    } finally {
      setLoadingId(null)
    }
  }, [startPolling])

  const handleReset = useCallback(async (id: string) => {
    try {
      await resetScenario(id)
      setStates((prev) => {
        const next = { ...prev }
        delete next[id]
        return next
      })
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e))
    }
  }, [])

  const handleSelect = useCallback((id: string) => {
    setActiveScenarioId(id)
    // Fetch state once when selecting so the dashboard shows something immediately
    pollScenario(id)
  }, [pollScenario])

  const refreshConfig = useCallback(() => {
    refreshHealthAndScenarios()
  }, [refreshHealthAndScenarios])

  return {
    health,
    backendOnline,
    scenarios,
    states,
    activeScenarioId,
    loadingId,
    error,
    handleRun,
    handleReset,
    handleSelect,
    refreshConfig,
  }
}
