import type {
  ConfigResponse,
  ConfigUpdate,
  HealthStatus,
  InvestigationState,
  ScenarioInfo,
} from './types'

const BASE = '/api'

// ─── Helpers ─────────────────────────────────────────────────────────────────

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    headers: { 'Content-Type': 'application/json', ...init?.headers },
    ...init,
  })

  if (!res.ok) {
    const body = await res.text().catch(() => res.statusText)
    throw new ApiError(res.status, body)
  }

  return res.json() as Promise<T>
}

export class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message)
    this.name = 'ApiError'
  }
}

// ─── Health ──────────────────────────────────────────────────────────────────

export const getHealth = () =>
  request<HealthStatus>('/health')

// ─── Scenarios ───────────────────────────────────────────────────────────────

export const getScenarios = () =>
  request<ScenarioInfo[]>('/scenarios')

export const runScenario = (scenarioId: string) =>
  request<{ status: string; scenario_id: string; message: string }>(
    `/scenarios/${scenarioId}/run`,
    { method: 'POST' },
  )

export const getScenarioState = (scenarioId: string) =>
  request<InvestigationState>(`/scenarios/${scenarioId}/state`)

export const resetScenario = (scenarioId: string) =>
  request<{ status: string; scenario_id: string }>(
    `/scenarios/${scenarioId}/reset`,
    { method: 'POST' },
  )

// ─── Config ──────────────────────────────────────────────────────────────────

export const updateConfig = (update: ConfigUpdate) =>
  request<ConfigResponse>('/config', {
    method: 'POST',
    body: JSON.stringify(update),
  })

export const getIncidentReport = (scenarioId: string) =>
  request<Record<string, unknown>>(`/scenarios/${scenarioId}/report`)
