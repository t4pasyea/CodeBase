// ─── Enums ───────────────────────────────────────────────────────────────────

export type ClassificationTag = 'DATA' | 'INSTRUCTION_SHAPED'
export type GateDecisionType  = 'ACT' | 'CONTINUE' | 'ESCALATE'
export type VerificationResultType = 'MATCH' | 'MISMATCH'
export type HypothesisStatus  = 'active' | 'revised' | 'rejected'
export type ActorType =
  | 'AI' | 'GATE' | 'ACTION' | 'VERIFICATION' | 'ORCHESTRATOR' | 'CLASSIFIER'
  | 'LOG_ANALYSIS_AGENT' | 'THREAT_INVESTIGATION_AGENT'
export type ScenarioStatus = 'idle' | 'running' | 'completed' | 'escalated' | 'error'
export type RiskLevel = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL'

// ─── Core models (mirrors backend Pydantic schemas) ──────────────────────────

export interface EvidenceItem {
  id: string
  source_id: string
  collector_id: string | null
  upstream_id: string | null
  timestamp: number
  raw_content: string
  classification_tag: ClassificationTag | null
  normalized_event: NormalizedEvent | null
}

export interface NormalizedEvent {
  evidence_id: string
  event_type: string
  severity: string
  source_system: string
  actor: string | null
  target: string | null
  mitre_tactic: string | null
  mitre_technique: string | null
  anomaly_flags: string[]
  summary: string
  raw_evidence_id: string
}

export interface RiskAssessment {
  risk_score: number
  risk_level: RiskLevel
  explanation: string
  recommended_action: string
  supporting_evidence_ids: string[]
  mitre_techniques: string[]
}

export interface ActionProposal {
  action_type: string
  target: string
  supporting_evidence_ids: string[]
  justification: string | null
}

export interface GateDecision {
  decision: GateDecisionType
  reason: string
  independent_source_count: number
  required_count: number
}

export interface ActionReport {
  action_type: string
  target: string
  claimed_state: Record<string, unknown>
  success: boolean
}

export interface VerificationResult {
  result: VerificationResultType
  expected_state: Record<string, unknown>
  actual_state: Record<string, unknown>
  details: string
}

export interface Hypothesis {
  id: string
  description: string
  supporting_evidence_ids: string[]
  status: HypothesisStatus
}

export interface AuditEntry {
  timestamp: number
  actor: ActorType
  event_type: string
  details: string
  step_number: number
}

export interface InvestigationState {
  scenario_id: string
  scenario_name: string
  status: ScenarioStatus
  step_count: number
  max_steps: number
  evidence_store: EvidenceItem[]
  hypotheses: Hypothesis[]
  audit_log: AuditEntry[]
  gate_decisions: GateDecision[]
  final_outcome: string | null
  available_sources: string[]
  investigated_sources: string[]
  risk_assessment: RiskAssessment | null
  verification_result: VerificationResult | null
}

// ─── Scenario info ────────────────────────────────────────────────────────────

export interface ScenarioInfo {
  id: string
  name: string
  description: string
  force_lie: boolean
  expected_outcome: string
}

// ─── Health ──────────────────────────────────────────────────────────────────

export interface HealthStatus {
  status: string
  service: string
  fallback_mode: boolean
  max_steps: number
}

// ─── Config ──────────────────────────────────────────────────────────────────

export interface ConfigUpdate {
  use_fallback?: boolean
  max_steps?: number
  gemini_api_key?: string
}

export interface ConfigResponse {
  status: string
  config: {
    use_fallback: boolean
    max_steps: number
    has_api_key: boolean
  }
}
