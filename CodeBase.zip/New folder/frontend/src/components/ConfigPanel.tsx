import { useState } from 'react'
import { Settings, Key, Cpu, Sliders, CheckCircle2, AlertCircle, X } from 'lucide-react'
import { cn } from '../lib/utils'
import { Button } from './ui/Button'
import { Panel } from './ui/Panel'
import { Badge } from './ui/Badge'
import { updateConfig } from '../api/client'
import type { HealthStatus } from '../api/types'

interface ConfigPanelProps {
  health: HealthStatus | null
  onClose: () => void
  onUpdated: () => void
}

export function ConfigPanel({ health, onClose, onUpdated }: ConfigPanelProps) {
  const [fallbackMode, setFallbackMode]   = useState<boolean>(health?.fallback_mode ?? true)
  const [maxSteps, setMaxSteps]           = useState<number>(health?.max_steps ?? 8)
  const [apiKey, setApiKey]               = useState<string>('')
  const [loading, setLoading]             = useState(false)
  const [result, setResult]               = useState<'success' | 'error' | null>(null)
  const [errorMsg, setErrorMsg]           = useState('')

  async function handleSave() {
    setLoading(true)
    setResult(null)
    try {
      await updateConfig({
        use_fallback: fallbackMode,
        max_steps: maxSteps,
        ...(apiKey.trim() ? { gemini_api_key: apiKey.trim() } : {}),
      })
      setResult('success')
      setApiKey('')
      onUpdated()
    } catch (e) {
      setResult('error')
      setErrorMsg(e instanceof Error ? e.message : String(e))
    } finally {
      setLoading(false)
    }
  }

  return (
    /* Backdrop */
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4"
      onClick={(e) => e.target === e.currentTarget && onClose()}
    >
      <div className="w-full max-w-lg rounded-2xl border border-white/[0.08] bg-surface-200 shadow-2xl animate-slide-up">
        {/* Modal header */}
        <div className="flex items-center justify-between border-b border-white/[0.06] px-6 py-4">
          <div className="flex items-center gap-2">
            <Settings className="h-4 w-4 text-brand" />
            <span className="font-semibold text-white">Configuration</span>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-500 hover:bg-white/5 hover:text-white transition"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Body */}
        <div className="space-y-5 p-6">
          {/* Current status */}
          {health && (
            <Panel title="Current Status" icon={<Cpu className="h-4 w-4" />}>
              <div className="flex flex-wrap gap-2">
                <Badge variant={health.fallback_mode ? 'ghost' : 'brand'} dot>
                  {health.fallback_mode ? 'FALLBACK MODE' : 'LLM LIVE'}
                </Badge>
                <Badge variant="ghost">
                  max steps: {health.max_steps}
                </Badge>
                <Badge variant={health.status === 'healthy' ? 'act' : 'escalate'} dot>
                  {health.status}
                </Badge>
              </div>
            </Panel>
          )}

          {/* Fallback toggle */}
          <div className="space-y-2">
            <label className="flex items-center justify-between gap-4 cursor-pointer">
              <div className="space-y-0.5">
                <p className="text-sm font-medium text-white">Fallback Mode</p>
                <p className="text-xs text-slate-500">
                  Use pre-recorded responses instead of live Gemini API. Required when no API key is set.
                </p>
              </div>
              <button
                type="button"
                role="switch"
                aria-checked={fallbackMode}
                onClick={() => setFallbackMode((v) => !v)}
                className={cn(
                  'relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200',
                  fallbackMode ? 'bg-brand' : 'bg-white/10',
                )}
              >
                <span
                  className={cn(
                    'inline-block h-5 w-5 transform rounded-full bg-white shadow-sm transition-transform duration-200',
                    fallbackMode ? 'translate-x-5' : 'translate-x-0',
                  )}
                />
              </button>
            </label>
          </div>

          {/* Max steps */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-white">
                <Sliders className="mr-1.5 inline h-3.5 w-3.5 text-brand" />
                Max Investigation Steps
              </label>
              <span className="font-mono text-sm font-bold text-brand">{maxSteps}</span>
            </div>
            <input
              type="range"
              min={3}
              max={20}
              value={maxSteps}
              onChange={(e) => setMaxSteps(Number(e.target.value))}
              className="w-full accent-brand"
            />
            <div className="flex justify-between font-mono text-[10px] text-slate-600">
              <span>3 (fast)</span>
              <span>20 (thorough)</span>
            </div>
          </div>

          {/* Gemini API key */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-white">
              <Key className="mr-1.5 inline h-3.5 w-3.5 text-brand" />
              Gemini API Key
            </label>
            <p className="text-xs text-slate-500">
              Required for live LLM mode. Leave blank to keep the current key (if set).
            </p>
            <input
              type="password"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder="AIzaSy…"
              className="w-full rounded-lg border border-white/5 bg-white/[0.03] px-3 py-2 font-mono text-xs text-slate-300 placeholder:text-slate-600 focus:border-brand/30 focus:outline-none"
            />
          </div>

          {/* Result message */}
          {result === 'success' && (
            <div className="flex items-center gap-2 rounded-lg border border-gate-act/20 bg-gate-act/10 px-3 py-2 text-xs text-gate-act animate-fade-in">
              <CheckCircle2 className="h-4 w-4 shrink-0" />
              Configuration saved successfully
            </div>
          )}
          {result === 'error' && (
            <div className="flex items-center gap-2 rounded-lg border border-gate-escalate/20 bg-gate-escalate/10 px-3 py-2 text-xs text-gate-escalate animate-fade-in">
              <AlertCircle className="h-4 w-4 shrink-0" />
              {errorMsg || 'Failed to save configuration'}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="flex items-center justify-end gap-3 border-t border-white/[0.06] px-6 py-4">
          <Button variant="ghost" size="sm" onClick={onClose}>Cancel</Button>
          <Button variant="primary" size="sm" loading={loading} onClick={handleSave}>
            Save Changes
          </Button>
        </div>
      </div>
    </div>
  )
}
