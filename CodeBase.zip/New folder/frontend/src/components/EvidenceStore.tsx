import { useState } from 'react'
import { Database, ChevronDown, ChevronUp, Search, Filter, AlertTriangle } from 'lucide-react'
import { cn, formatTimestamp } from '../lib/utils'
import { Badge } from './ui/Badge'
import { Panel } from './ui/Panel'
import type { EvidenceItem, ClassificationTag } from '../api/types'

interface EvidenceStoreProps {
  items: EvidenceItem[]
}

// ─── Classification badge ─────────────────────────────────────────────────────

function ClassTag({ tag }: { tag: ClassificationTag | null }) {
  if (!tag) return <Badge variant="ghost">UNCLASSIFIED</Badge>
  return (
    <Badge variant={tag === 'DATA' ? 'data' : 'instruction'} dot>
      {tag === 'DATA' ? 'DATA' : 'INSTRUCTION_SHAPED'}
    </Badge>
  )
}

// ─── Provenance pill ──────────────────────────────────────────────────────────

function ProvPill({ label, value }: { label: string; value: string | null }) {
  return (
    <div className="rounded-md border border-white/5 bg-white/[0.03] px-2 py-1 min-w-0">
      <p className="text-[10px] font-mono text-slate-600">{label}</p>
      <p className="truncate font-mono text-xs text-slate-300">{value ?? '—'}</p>
    </div>
  )
}

// ─── Evidence card ────────────────────────────────────────────────────────────

function EvidenceCard({ item, index }: { item: EvidenceItem; index: number }) {
  const [expanded, setExpanded] = useState(false)
  const isPoisoned = item.classification_tag === 'INSTRUCTION_SHAPED'
  const hasProvenance = item.collector_id && item.upstream_id

  return (
    <div
      className={cn(
        'rounded-xl border transition-all duration-200',
        isPoisoned
          ? 'border-evidence-instruction/20 bg-evidence-instruction/5'
          : 'border-white/[0.06] bg-surface-200',
        'animate-slide-up',
      )}
      style={{ animationDelay: `${index * 40}ms` }}
    >
      {/* Card header */}
      <button
        className="flex w-full items-start gap-3 p-4 text-left"
        onClick={() => setExpanded((v) => !v)}
      >
        {/* ID badge */}
        <div className={cn(
          'mt-0.5 flex h-7 w-14 shrink-0 items-center justify-center rounded-lg font-mono text-xs font-bold',
          isPoisoned ? 'bg-evidence-instruction/15 text-evidence-instruction' : 'bg-evidence-data/10 text-evidence-data',
        )}>
          {item.id}
        </div>

        <div className="flex-1 min-w-0 space-y-1.5">
          {/* Top row */}
          <div className="flex items-center gap-2 flex-wrap">
            <span className="font-mono text-xs text-slate-400">{item.source_id}</span>
            <ClassTag tag={item.classification_tag} />
            {!hasProvenance && (
              <Badge variant="escalate">NULL PROVENANCE</Badge>
            )}
            {isPoisoned && (
              <span className="flex items-center gap-1 text-xs text-evidence-instruction">
                <AlertTriangle className="h-3 w-3" />
                Prompt injection detected
              </span>
            )}
          </div>

          {/* Content preview */}
          <p className="text-xs leading-relaxed text-slate-400 line-clamp-2">
            {item.raw_content}
          </p>
          {/* Anomaly flags quick view */}
          {item.normalized_event && item.normalized_event.anomaly_flags.length > 0 && !expanded && (
            <div className="flex flex-wrap gap-1 mt-0.5">
              {item.normalized_event.anomaly_flags.slice(0, 3).map((f) => (
                <span key={f} className="rounded border border-gate-continue/20 bg-gate-continue/10 px-1.5 py-0.5 font-mono text-[10px] text-gate-continue">
                  {f}
                </span>
              ))}
              {item.normalized_event.anomaly_flags.length > 3 && (
                <span className="text-[10px] text-slate-600">+{item.normalized_event.anomaly_flags.length - 3}</span>
              )}
            </div>
          )}
        </div>

        {/* Expand toggle */}
        <span className="mt-0.5 shrink-0 text-slate-600">
          {expanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
        </span>
      </button>

      {/* Expanded detail */}
      {expanded && (
        <div className="border-t border-white/[0.06] px-4 pb-4 pt-3 space-y-4 animate-fade-in">
          {/* Full raw content */}
          <div className="space-y-1">
            <p className="text-[10px] font-mono text-slate-600 uppercase tracking-wider">Raw Content</p>
            <pre className="whitespace-pre-wrap rounded-lg border border-white/5 bg-white/[0.02] p-3 font-mono text-xs leading-relaxed text-slate-300">
              {item.raw_content}
            </pre>
          </div>

          {/* Provenance triad */}
          <div className="space-y-1">
            <p className="text-[10px] font-mono text-slate-600 uppercase tracking-wider">
              Provenance Metadata — used by Trust Gate
            </p>
            <div className="grid grid-cols-3 gap-2">
              <ProvPill label="source_id"    value={item.source_id} />
              <ProvPill label="collector_id" value={item.collector_id} />
              <ProvPill label="upstream_id"  value={item.upstream_id} />
            </div>
          </div>

          {/* Normalized event */}
          {item.normalized_event && (
            <div className="space-y-1">
              <p className="text-[10px] font-mono text-slate-600 uppercase tracking-wider">
                Log Analysis Agent — Normalized Event
              </p>
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                <ProvPill label="event_type" value={item.normalized_event.event_type} />
                <ProvPill label="severity"   value={item.normalized_event.severity} />
                {item.normalized_event.mitre_technique && (
                  <ProvPill label="MITRE" value={item.normalized_event.mitre_technique} />
                )}
              </div>
              {item.normalized_event.anomaly_flags.length > 0 && (
                <div className="flex flex-wrap gap-1.5 mt-1">
                  {item.normalized_event.anomaly_flags.map((f) => (
                    <span key={f} className="rounded border border-gate-continue/20 bg-gate-continue/10 px-2 py-0.5 font-mono text-[10px] text-gate-continue">
                      {f}
                    </span>
                  ))}
                </div>
              )}
              <p className="text-xs italic text-slate-500">{item.normalized_event.summary}</p>
            </div>
          )}

          {/* Timestamp */}
          <p className="text-[10px] font-mono text-slate-600">
            Collected at {formatTimestamp(item.timestamp)}
          </p>
        </div>
      )}
    </div>
  )
}

// ─── Main component ───────────────────────────────────────────────────────────

type FilterType = 'all' | 'DATA' | 'INSTRUCTION_SHAPED' | 'null_provenance'

export function EvidenceStore({ items }: EvidenceStoreProps) {
  const [search, setSearch]   = useState('')
  const [filter, setFilter]   = useState<FilterType>('all')

  const poisonedCount    = items.filter((i) => i.classification_tag === 'INSTRUCTION_SHAPED').length
  const nullProvCount    = items.filter((i) => !i.collector_id || !i.upstream_id).length

  const filtered = items.filter((item) => {
    const matchesFilter =
      filter === 'all'               ? true :
      filter === 'DATA'              ? item.classification_tag === 'DATA' :
      filter === 'INSTRUCTION_SHAPED'? item.classification_tag === 'INSTRUCTION_SHAPED' :
      filter === 'null_provenance'   ? (!item.collector_id || !item.upstream_id) :
      true
    const matchesSearch =
      search === '' ||
      item.id.includes(search) ||
      item.source_id.toLowerCase().includes(search.toLowerCase()) ||
      item.raw_content.toLowerCase().includes(search.toLowerCase())
    return matchesFilter && matchesSearch
  })

  return (
    <div className="flex flex-col gap-4">
      {/* Page header */}
      <div className="space-y-1">
        <h2 className="text-lg font-semibold text-white">Evidence Store</h2>
        <p className="text-sm text-slate-500">
          All evidence collected during the investigation. Each item is classified by the AI
          and its provenance metadata is evaluated by the Trust Gate.
        </p>
      </div>

      {/* Totals row */}
      <div className="flex flex-wrap gap-2">
        <Badge variant="data" dot>{items.length} total</Badge>
        {poisonedCount > 0 && (
          <Badge variant="instruction" dot>{poisonedCount} instruction-shaped</Badge>
        )}
        {nullProvCount > 0 && (
          <Badge variant="escalate" dot>{nullProvCount} null provenance</Badge>
        )}
      </div>

      {/* Search + filter */}
      <Panel noPad>
        <div className="flex flex-col gap-2 p-3 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-slate-600" />
            <input
              type="text"
              placeholder="Search evidence…"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full rounded-lg border border-white/5 bg-white/[0.03] py-2 pl-8 pr-3 text-xs text-slate-300 placeholder:text-slate-600 focus:border-brand/30 focus:outline-none"
            />
          </div>
          <div className="flex items-center gap-1.5 flex-wrap">
            <Filter className="h-3.5 w-3.5 shrink-0 text-slate-600" />
            {(['all', 'DATA', 'INSTRUCTION_SHAPED', 'null_provenance'] as FilterType[]).map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={cn(
                  'rounded-md border px-2 py-1 font-mono text-xs transition',
                  filter === f
                    ? 'border-brand/40 bg-brand/10 text-brand'
                    : 'border-white/5 bg-white/[0.03] text-slate-500 hover:text-slate-300',
                )}
              >
                {f === 'null_provenance' ? 'NULL PROV' : f.toUpperCase()}
              </button>
            ))}
          </div>
        </div>
      </Panel>

      {/* Cards */}
      <div className="space-y-2">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center gap-3 rounded-xl border border-dashed border-white/10 py-12 text-center">
            <Database className="h-8 w-8 text-slate-700" />
            <p className="text-sm text-slate-500">
              {items.length === 0
                ? 'No evidence collected yet — run a scenario first'
                : 'No evidence matches this filter'}
            </p>
          </div>
        ) : (
          filtered.map((item, idx) => (
            <EvidenceCard key={item.id} item={item} index={idx} />
          ))
        )}
      </div>
    </div>
  )
}
