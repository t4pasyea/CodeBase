import {
  ShieldCheck, ShieldAlert, ShieldX, Clock, Activity,
  Database, BrainCircuit, CheckCircle2, XCircle, AlertCircle,
  Cpu, Download, TrendingUp,
} from 'lucide-react'
import { cn, formatTimestamp } from '../lib/utils'
import { Panel } from './ui/Panel'
import { Badge } from './ui/Badge'
import { ProgressBar } from './ui/ProgressBar'
import { Button } from './ui/Button'
import { getIncidentReport } from '../api/client'
import type { InvestigationState, ScenarioStatus, RiskLevel } from '../api/types'

interface InvestigationDashboardProps {
  state: InvestigationState | null
  scenarioName: string
}

// ─── Risk level config ────────────────────────────────────────────────────────

const RISK_CFG: Record<RiskLevel, { color: string; bar: 'brand' | 'act' | 'continue' | 'escalate'; bg: string; border: string }> = {
  LOW:      { color: 'text-gate-act',      bar: 'act',      bg: 'bg-gate-act/10',      border: 'border-gate-act/20' },
  MEDIUM:   { color: 'text-gate-continue', bar: 'continue', bg: 'bg-gate-continue/10', border: 'border-gate-continue/20' },
  HIGH:     { color: 'text-threat-high',   bar: 'continue', bg: 'bg-threat-high/10',   border: 'border-threat-high/20' },
  CRITICAL: { color: 'text-gate-escalate', bar: 'escalate', bg: 'bg-gate-escalate/10', border: 'border-gate-escalate/20' },
}

// ─── Risk panel ───────────────────────────────────────────────────────────────

function RiskPanel({ state }: { state: InvestigationState }) {
  const ra = state.risk_assessment
  if (!ra) return (
    <div className="flex items-center gap-2 text-xs text-slate-500 italic py-2">
      <TrendingUp className="h-3.5 w-3.5" />
      Risk assessment pending…
    </div>
  )

  const cfg = RISK_CFG[ra.risk_level as RiskLevel] ?? RISK_CFG.MEDIUM

  return (
    <div className="space-y-3">
      {/* Score meter */}
      <div className={cn('flex items-center gap-3 rounded-xl border p-3', cfg.bg, cfg.border)}>
        <div className={cn('flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-white/5', cfg.color)}>
          <TrendingUp className="h-5 w-5" />
        </div>
        <div className="flex-1 min-w-0 space-y-1">
          <div className="flex items-center gap-2">
            <span className={cn('font-mono text-lg font-bold', cfg.color)}>
              {ra.risk_score.toFixed(0)}/100
            </span>
            <Badge variant={
              ra.risk_level === 'CRITICAL' ? 'escalate' :
              ra.risk_level === 'HIGH'     ? 'continue' :
              ra.risk_level === 'MEDIUM'   ? 'continue' : 'act'
            }>
              {ra.risk_level}
            </Badge>
            <span className="text-[10px] text-slate-600 font-mono">ADVISORY ONLY — not used by gate</span>
          </div>
          <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/5">
            <div
              className={cn('h-full rounded-full transition-all duration-700',
                ra.risk_level === 'CRITICAL' ? 'bg-gate-escalate' :
                ra.risk_level === 'HIGH'     ? 'bg-threat-high' :
                ra.risk_level === 'MEDIUM'   ? 'bg-gate-continue' : 'bg-gate-act'
              )}
              style={{ width: `${ra.risk_score}%` }}
            />
          </div>
        </div>
      </div>

      {/* Explanation */}
      <div className="rounded-lg border border-white/5 bg-white/[0.02] px-3 py-2">
        <p className="text-[10px] font-mono text-slate-600 uppercase tracking-wider mb-1">
          Threat Investigation Agent — Evidence-backed Explanation
        </p>
        <p className="text-xs leading-relaxed text-slate-300">{ra.explanation}</p>
      </div>

      {/* Recommended action */}
      <div className="flex items-start gap-2 text-xs text-slate-400">
        <ShieldCheck className="h-3.5 w-3.5 mt-0.5 shrink-0 text-brand" />
        <span><span className="text-slate-300 font-medium">Recommended:</span> {ra.recommended_action}</span>
      </div>

      {/* MITRE techniques */}
      {ra.mitre_techniques.length > 0 && (
        <div className="flex flex-wrap gap-1.5">
          {ra.mitre_techniques.map((t) => (
            <span key={t} className="rounded border border-brand/20 bg-brand/5 px-2 py-0.5 font-mono text-[10px] text-brand">
              {t}
            </span>
          ))}
        </div>
      )}
    </div>
  )
}

// ─── Agent pipeline banner ────────────────────────────────────────────────────

function AgentPipelineBanner() {
  const agents = [
    {
      icon: <Cpu className="h-4 w-4" />,
      name: 'Log Analysis Agent',
      role: 'Normalise · Classify · Detect anomalies',
      color: 'text-actor-classifier',
      bg: 'bg-actor-classifier/10 border-actor-classifier/20',
    },
    {
      icon: <BrainCircuit className="h-4 w-4" />,
      name: 'Threat Investigation Agent',
      role: 'Hypotheses · Correlate · Risk score · Propose',
      color: 'text-actor-ai',
      bg: 'bg-actor-ai/10 border-actor-ai/20',
    },
    {
      icon: <ShieldCheck className="h-4 w-4" />,
      name: 'Trust Gate',
      role: 'Deterministic · Provenance-only · ACT / CONTINUE / ESCALATE',
      color: 'text-actor-gate',
      bg: 'bg-actor-gate/10 border-actor-gate/20',
    },
  ]

  return (
    <div className="grid gap-2 sm:grid-cols-3">
      {agents.map((a, i) => (
        <div key={i} className={cn('flex items-center gap-3 rounded-xl border px-3 py-2.5', a.bg)}>
          <span className={cn('shrink-0', a.color)}>{a.icon}</span>
          <div className="min-w-0">
            <p className={cn('text-xs font-semibold truncate', a.color)}>{a.name}</p>
            <p className="text-[10px] text-slate-500 leading-snug">{a.role}</p>
          </div>
        </div>
      ))}
    </div>
  )
}

// ─── Status config ────────────────────────────────────────────────────────────

interface StatusConfig {
  icon: React.ReactNode
  label: string
  color: string
  glow: string
  description: string
}

const STATUS_CONFIG: Record<ScenarioStatus, StatusConfig> = {
  idle: {
    icon: <Clock className="h-5 w-5" />,
    label: 'IDLE',
    color: 'text-slate-500',
    glow: '',
    description: 'No investigation running. Select a scenario to begin.',
  },
  running: {
    icon: <Activity className="h-5 w-5 animate-pulse" />,
    label: 'INVESTIGATING',
    color: 'text-brand',
    glow: 'shadow-glow-brand',
    description: 'AI agent is actively collecting evidence and forming hypotheses.',
  },
  completed: {
    icon: <CheckCircle2 className="h-5 w-5" />,
    label: 'COMPLETED',
    color: 'text-gate-act',
    glow: 'shadow-glow-act',
    description: 'Investigation complete. Action authorized and verified.',
  },
  escalated: {
    icon: <ShieldAlert className="h-5 w-5" />,
    label: 'ESCALATED',
    color: 'text-gate-escalate',
    glow: 'shadow-glow-escalate',
    description: 'Escalated to human analyst — gate blocked automated action.',
  },
  error: {
    icon: <XCircle className="h-5 w-5" />,
    label: 'ERROR',
    color: 'text-threat-critical',
    glow: '',
    description: 'An unexpected error occurred during investigation.',
  },
}

// ─── Stat card ────────────────────────────────────────────────────────────────

function StatCard({
  icon,
  label,
  value,
  sub,
  color,
}: {
  icon: React.ReactNode
  label: string
  value: string | number
  sub?: string
  color?: string
}) {
  return (
    <div className="flex items-center gap-3 rounded-xl border border-white/[0.06] bg-white/[0.03] p-4">
      <div className={cn('flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-white/5', color)}>
        {icon}
      </div>
      <div>
        <p className="text-xs text-slate-500">{label}</p>
        <p className="font-mono text-lg font-semibold text-white">{value}</p>
        {sub && <p className="text-xs text-slate-600">{sub}</p>}
      </div>
    </div>
  )
}

// ─── Gate summary ─────────────────────────────────────────────────────────────

function GateSummary({ state }: { state: InvestigationState }) {
  const counts = { ACT: 0, CONTINUE: 0, ESCALATE: 0 }
  for (const d of state.gate_decisions) {
    counts[d.decision as keyof typeof counts]++
  }

  const total = state.gate_decisions.length

  return (
    <div className="space-y-3">
      <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">Trust Gate Decisions</p>
      {total === 0 ? (
        <p className="text-xs text-slate-600 italic">No gate decisions yet</p>
      ) : (
        <div className="space-y-2">
          {/* ACT */}
          <div className="flex items-center gap-3">
            <div className="flex w-20 items-center gap-1.5">
              <ShieldCheck className="h-3.5 w-3.5 text-gate-act" />
              <span className="text-xs font-mono text-gate-act">ACT</span>
            </div>
            <div className="flex-1">
              <div className="h-2 w-full overflow-hidden rounded-full bg-white/5">
                <div
                  className="h-full rounded-full bg-gate-act transition-all duration-700"
                  style={{ width: total ? `${(counts.ACT / total) * 100}%` : '0%' }}
                />
              </div>
            </div>
            <span className="w-4 text-right font-mono text-xs text-gate-act">{counts.ACT}</span>
          </div>
          {/* CONTINUE */}
          <div className="flex items-center gap-3">
            <div className="flex w-20 items-center gap-1.5">
              <AlertCircle className="h-3.5 w-3.5 text-gate-continue" />
              <span className="text-xs font-mono text-gate-continue">CONTINUE</span>
            </div>
            <div className="flex-1">
              <div className="h-2 w-full overflow-hidden rounded-full bg-white/5">
                <div
                  className="h-full rounded-full bg-gate-continue transition-all duration-700"
                  style={{ width: total ? `${(counts.CONTINUE / total) * 100}%` : '0%' }}
                />
              </div>
            </div>
            <span className="w-4 text-right font-mono text-xs text-gate-continue">{counts.CONTINUE}</span>
          </div>
          {/* ESCALATE */}
          <div className="flex items-center gap-3">
            <div className="flex w-20 items-center gap-1.5">
              <ShieldX className="h-3.5 w-3.5 text-gate-escalate" />
              <span className="text-xs font-mono text-gate-escalate">ESCALATE</span>
            </div>
            <div className="flex-1">
              <div className="h-2 w-full overflow-hidden rounded-full bg-white/5">
                <div
                  className="h-full rounded-full bg-gate-escalate transition-all duration-700"
                  style={{ width: total ? `${(counts.ESCALATE / total) * 100}%` : '0%' }}
                />
              </div>
            </div>
            <span className="w-4 text-right font-mono text-xs text-gate-escalate">{counts.ESCALATE}</span>
          </div>
        </div>
      )}
    </div>
  )
}

// ─── Source coverage ─────────────────────────────────────────────────────────

function SourceCoverage({ state }: { state: InvestigationState }) {
  const all         = state.available_sources
  const investigated = new Set(state.investigated_sources)

  if (all.length === 0) return null

  return (
    <div className="space-y-2">
      <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">Source Coverage</p>
      <div className="flex flex-wrap gap-1.5">
        {all.map((src) => {
          const done = investigated.has(src)
          return (
            <span
              key={src}
              className={cn(
                'rounded-md border px-2 py-0.5 font-mono text-[10px] transition-all',
                done
                  ? 'border-gate-act/30 bg-gate-act/10 text-gate-act'
                  : 'border-white/10 bg-white/[0.03] text-slate-600',
              )}
            >
              {src.replace(/-\d+$/, '')}
            </span>
          )
        })}
      </div>
      <p className="text-xs text-slate-600">
        {investigated.size} of {all.length} sources investigated
      </p>
    </div>
  )
}

// ─── Main component ───────────────────────────────────────────────────────────

export function InvestigationDashboard({ state, scenarioName }: InvestigationDashboardProps) {
  const status     = state?.status ?? 'idle'
  const cfg        = STATUS_CONFIG[status]
  const stepCount  = state?.step_count ?? 0
  const maxSteps   = state?.max_steps ?? 8
  const budgetPct  = maxSteps > 0 ? (stepCount / maxSteps) * 100 : 0
  const budgetColor =
    budgetPct >= 80 ? 'escalate' :
    budgetPct >= 50 ? 'continue' :
    'brand'

  async function handleDownloadReport() {
    if (!state?.scenario_id) return
    try {
      const report = await getIncidentReport(state.scenario_id)
      const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' })
      const url  = URL.createObjectURL(blob)
      const a    = document.createElement('a')
      a.href     = url
      a.download = `skeptic-report-${state.scenario_id}-${Date.now()}.json`
      a.click()
      URL.revokeObjectURL(url)
    } catch (e) {
      console.error('Report download failed', e)
    }
  }

  return (
    <div className="flex flex-col gap-4">
      {/* Page header */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h2 className="text-lg font-semibold text-white">Investigation Dashboard</h2>
          <p className="text-sm text-slate-500">
            {scenarioName || 'No scenario selected'}
          </p>
        </div>
        {state && (status === 'completed' || status === 'escalated') && (
          <Button
            variant="outline"
            size="sm"
            icon={<Download className="h-3.5 w-3.5" />}
            onClick={handleDownloadReport}
          >
            Download Report
          </Button>
        )}
      </div>

      {/* Agent pipeline */}
      <AgentPipelineBanner />

      {/* Status hero */}
      <div
        className={cn(
          'flex items-center gap-4 rounded-xl border border-white/[0.06] bg-surface-200 p-5',
          state && status !== 'idle' && cfg.glow,
        )}
      >
        <div className={cn(
          'flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-white/5',
          cfg.color,
        )}>
          {cfg.icon}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap">
            <span className={cn('font-mono text-base font-bold', cfg.color)}>
              {cfg.label}
            </span>
            {status === 'running' && (
              <span className="h-2 w-2 animate-ping rounded-full bg-brand opacity-75" />
            )}
          </div>
          <p className="mt-0.5 text-sm text-slate-500">{cfg.description}</p>
          {state?.final_outcome && (
            <p className="mt-1 text-xs italic text-slate-400 border-l-2 border-white/10 pl-2">
              {state.final_outcome}
            </p>
          )}
        </div>
        {state && (
          <Badge variant={status === 'running' ? 'running' : status === 'completed' ? 'completed' : status === 'escalated' ? 'escalate' : 'idle'}>
            {state.scenario_id.toUpperCase()}
          </Badge>
        )}
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <StatCard
          icon={<Activity className="h-4 w-4" />}
          label="Steps Used"
          value={`${stepCount}/${maxSteps}`}
          sub="investigation budget"
          color="text-brand"
        />
        <StatCard
          icon={<Database className="h-4 w-4" />}
          label="Evidence Items"
          value={state?.evidence_store.length ?? 0}
          sub="collected & classified"
          color="text-evidence-data"
        />
        <StatCard
          icon={<BrainCircuit className="h-4 w-4" />}
          label="Hypotheses"
          value={state?.hypotheses.length ?? 0}
          sub="active + resolved"
          color="text-hyp-active"
        />
        <StatCard
          icon={<ShieldCheck className="h-4 w-4" />}
          label="Gate Decisions"
          value={state?.gate_decisions.length ?? 0}
          sub="total evaluations"
          color="text-actor-gate"
        />
      </div>

      {/* Budget meter */}
      {state && status !== 'idle' && (
        <Panel title="Investigation Budget" icon={<Clock className="h-4 w-4" />}>
          <div className="space-y-3">
            <ProgressBar
              value={stepCount}
              max={maxSteps}
              color={budgetColor}
              showValue
              animated={status === 'running'}
            />
            <div className="flex items-center justify-between text-xs text-slate-500">
              <span>
                {maxSteps - stepCount} step{maxSteps - stepCount !== 1 ? 's' : ''} remaining
              </span>
              <span className={cn(
                'font-mono font-medium',
                budgetColor === 'escalate' ? 'text-gate-escalate' :
                budgetColor === 'continue' ? 'text-gate-continue' :
                'text-brand',
              )}>
                {budgetPct >= 80 ? '⚠ LOW BUDGET' : budgetPct >= 50 ? 'HALFWAY' : 'HEALTHY'}
              </span>
            </div>
          </div>
        </Panel>
      )}

      {/* Risk assessment */}
      {state && status !== 'idle' && (
        <Panel title="Risk Assessment" icon={<TrendingUp className="h-4 w-4" />}
          subtitle="Produced by Threat Investigation Agent — advisory only">
          <RiskPanel state={state} />
        </Panel>
      )}

      {/* Bottom row */}
      {state && status !== 'idle' && (
        <div className="grid gap-4 lg:grid-cols-2">
          <Panel title="Gate Decision Summary" icon={<ShieldCheck className="h-4 w-4" />}>
            <GateSummary state={state} />
          </Panel>
          <Panel title="Source Coverage" icon={<Database className="h-4 w-4" />}>
            <SourceCoverage state={state} />
          </Panel>
        </div>
      )}

      {/* Idle placeholder */}
      {(!state || status === 'idle') && (
        <div className="flex flex-col items-center gap-4 rounded-xl border border-dashed border-white/10 py-20 text-center">
          <ShieldCheck className="h-10 w-10 text-slate-700" />
          <div>
            <p className="text-sm font-medium text-slate-500">No active investigation</p>
            <p className="text-xs text-slate-600 mt-1">Go to Scenarios and run one to see live data here</p>
          </div>
        </div>
      )}
    </div>
  )
}
