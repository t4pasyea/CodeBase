import { useState } from 'react'
import {
  ScrollText, BrainCircuit, ShieldCheck, Zap,
  CheckCircle2, Settings, Cpu, Filter,
} from 'lucide-react'
import { cn, formatTimestamp } from '../lib/utils'
import { Badge } from './ui/Badge'
import type { AuditEntry, ActorType } from '../api/types'

// ─── Actor config ─────────────────────────────────────────────────────────────

const ACTOR_CFG: Record<
  ActorType,
  { icon: React.ReactNode; label: string; color: string; dot: string }
> = {
  AI: {
    icon:  <BrainCircuit className="h-3.5 w-3.5" />,
    label: 'AI Agent',
    color: 'text-actor-ai',
    dot:   'bg-actor-ai',
  },
  GATE: {
    icon:  <ShieldCheck className="h-3.5 w-3.5" />,
    label: 'Trust Gate',
    color: 'text-actor-gate',
    dot:   'bg-actor-gate',
  },
  ACTION: {
    icon:  <Zap className="h-3.5 w-3.5" />,
    label: 'Action API',
    color: 'text-actor-action',
    dot:   'bg-actor-action',
  },
  VERIFICATION: {
    icon:  <CheckCircle2 className="h-3.5 w-3.5" />,
    label: 'Verification',
    color: 'text-actor-verification',
    dot:   'bg-actor-verification',
  },
  ORCHESTRATOR: {
    icon:  <Settings className="h-3.5 w-3.5" />,
    label: 'Orchestrator',
    color: 'text-actor-orchestrator',
    dot:   'bg-actor-orchestrator',
  },
  CLASSIFIER: {
    icon:  <Cpu className="h-3.5 w-3.5" />,
    label: 'Classifier',
    color: 'text-actor-classifier',
    dot:   'bg-actor-classifier',
  },
  LOG_ANALYSIS_AGENT: {
    icon:  <Cpu className="h-3.5 w-3.5" />,
    label: 'Log Analysis',
    color: 'text-actor-classifier',
    dot:   'bg-actor-classifier',
  },
  THREAT_INVESTIGATION_AGENT: {
    icon:  <BrainCircuit className="h-3.5 w-3.5" />,
    label: 'Threat Investigation',
    color: 'text-actor-ai',
    dot:   'bg-actor-ai',
  },
}

// ─── Event type → highlight colour ───────────────────────────────────────────

function detailHighlight(eventType: string): string {
  if (eventType.includes('escalat')) return 'border-gate-escalate/30'
  if (eventType.includes('act') || eventType.includes('complet')) return 'border-gate-act/30'
  if (eventType.includes('continu') || eventType.includes('gate')) return 'border-gate-continue/30'
  if (eventType.includes('poison') || eventType.includes('instruction')) return 'border-evidence-instruction/30'
  return 'border-white/5'
}

// ─── Single entry ─────────────────────────────────────────────────────────────

function TimelineEntry({
  entry,
  isLast,
}: {
  entry: AuditEntry
  isLast: boolean
}) {
  const actor = ACTOR_CFG[entry.actor as ActorType] ?? ACTOR_CFG.ORCHESTRATOR
  const [expanded, setExpanded] = useState(false)

  const isLong = entry.details.length > 160

  return (
    <div className="flex gap-3">
      {/* Spine */}
      <div className="flex flex-col items-center">
        <div
          className={cn(
            'mt-1 flex h-7 w-7 shrink-0 items-center justify-center rounded-full border border-white/10',
            `bg-white/[0.03] ${actor.color}`,
          )}
        >
          {actor.icon}
        </div>
        {!isLast && <div className="mt-1 flex-1 w-px bg-white/[0.06]" />}
      </div>

      {/* Content */}
      <div className={cn('flex-1 min-w-0 pb-5 animate-slide-up')}>
        {/* Header row */}
        <div className="flex items-center gap-2 flex-wrap">
          <span className={cn('text-xs font-semibold', actor.color)}>{actor.label}</span>
          <span className="rounded bg-white/5 px-1.5 py-0.5 font-mono text-[10px] text-slate-500">
            {entry.event_type}
          </span>
          {entry.step_number > 0 && (
            <span className="font-mono text-[10px] text-slate-700">step {entry.step_number}</span>
          )}
          <span className="ml-auto font-mono text-[10px] text-slate-700">
            {formatTimestamp(entry.timestamp)}
          </span>
        </div>

        {/* Details */}
        <div
          className={cn(
            'mt-2 rounded-lg border px-3 py-2 font-mono text-xs leading-relaxed text-slate-400',
            detailHighlight(entry.event_type),
            'bg-white/[0.02]',
          )}
        >
          <p className={cn(!expanded && isLong && 'line-clamp-3')}>
            {entry.details}
          </p>
          {isLong && (
            <button
              onClick={() => setExpanded((v) => !v)}
              className="mt-1.5 text-[10px] text-brand hover:underline"
            >
              {expanded ? 'Show less' : 'Show more'}
            </button>
          )}
        </div>
      </div>
    </div>
  )
}

// ─── Main component ───────────────────────────────────────────────────────────

type ActorFilter = ActorType | 'ALL'

export function AuditTimeline({ entries }: { entries: AuditEntry[] }) {
  const [actorFilter, setActorFilter] = useState<ActorFilter>('ALL')

  const actors = Array.from(new Set(entries.map((e) => e.actor))) as ActorType[]

  const filtered =
    actorFilter === 'ALL'
      ? entries
      : entries.filter((e) => e.actor === actorFilter)

  return (
    <div className="flex flex-col gap-4">
      {/* Page header */}
      <div className="space-y-1">
        <h2 className="text-lg font-semibold text-white">Audit Trail</h2>
        <p className="text-sm text-slate-500">
          Append-only, chronological record of every action taken by every actor in the system.
        </p>
      </div>

      {/* Filter pills */}
      {actors.length > 0 && (
        <div className="flex flex-wrap items-center gap-2">
          <Filter className="h-3.5 w-3.5 shrink-0 text-slate-600" />
          {(['ALL', ...actors] as ActorFilter[]).map((a) => {
            const cfg = a === 'ALL' ? null : ACTOR_CFG[a as ActorType]
            return (
              <button
                key={a}
                onClick={() => setActorFilter(a)}
                className={cn(
                  'rounded-md border px-2 py-1 font-mono text-xs transition',
                  actorFilter === a
                    ? `border-brand/40 bg-brand/10 text-brand`
                    : 'border-white/5 bg-white/[0.03] text-slate-500 hover:text-slate-300',
                )}
              >
                <span className="flex items-center gap-1.5">
                  {cfg && <span className={cfg.color}>{cfg.icon}</span>}
                  {a === 'ALL' ? 'ALL' : cfg?.label ?? a}
                </span>
              </button>
            )
          })}
          <span className="ml-auto font-mono text-xs text-slate-600">
            {filtered.length} event{filtered.length !== 1 ? 's' : ''}
          </span>
        </div>
      )}

      {/* Timeline */}
      {filtered.length === 0 ? (
        <div className="flex flex-col items-center gap-3 rounded-xl border border-dashed border-white/10 py-16 text-center">
          <ScrollText className="h-8 w-8 text-slate-700" />
          <p className="text-sm text-slate-500">
            {entries.length === 0
              ? 'No events yet — run a scenario to generate audit entries'
              : 'No events match this filter'}
          </p>
        </div>
      ) : (
        <div className="rounded-xl border border-white/[0.06] bg-surface-200 p-4">
          {filtered.map((entry, idx) => (
            <TimelineEntry
              key={`${entry.timestamp}-${idx}`}
              entry={entry}
              isLast={idx === filtered.length - 1}
            />
          ))}
        </div>
      )}

      {/* Summary footer */}
      {entries.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {(Object.keys(ACTOR_CFG) as ActorType[]).map((actor) => {
            const count = entries.filter((e) => e.actor === actor).length
            if (count === 0) return null
            const cfg = ACTOR_CFG[actor]
            const variantMap: Record<string, string> = {
              AI: 'ai', GATE: 'gate', ACTION: 'action', VERIFICATION: 'verification',
              ORCHESTRATOR: 'orchestrator', CLASSIFIER: 'classifier',
              LOG_ANALYSIS_AGENT: 'classifier', THREAT_INVESTIGATION_AGENT: 'ai',
            }
            return (
              <Badge key={actor} variant={variantMap[actor] as 'ai' | 'gate' | 'action' | 'verification' | 'orchestrator' | 'classifier'}>
                {cfg.label}: {count}
              </Badge>
            )
          })}
        </div>
      )}
    </div>
  )
}
