import {
  LayoutDashboard,
  Database,
  BrainCircuit,
  ScrollText,
  ShieldCheck,
  Play,
} from 'lucide-react'
import { cn } from '../../lib/utils'

export type ActivePanel =
  | 'dashboard'
  | 'evidence'
  | 'hypotheses'
  | 'audit'
  | 'gate'
  | 'scenarios'

interface NavItem {
  id: ActivePanel
  label: string
  icon: React.ReactNode
  description: string
}

const NAV_ITEMS: NavItem[] = [
  {
    id: 'scenarios',
    label: 'Scenarios',
    icon: <Play className="h-4 w-4" />,
    description: 'Select & run',
  },
  {
    id: 'dashboard',
    label: 'Dashboard',
    icon: <LayoutDashboard className="h-4 w-4" />,
    description: 'Live status',
  },
  {
    id: 'evidence',
    label: 'Evidence',
    icon: <Database className="h-4 w-4" />,
    description: 'Evidence store',
  },
  {
    id: 'hypotheses',
    label: 'Hypotheses',
    icon: <BrainCircuit className="h-4 w-4" />,
    description: 'AI reasoning',
  },
  {
    id: 'audit',
    label: 'Audit Log',
    icon: <ScrollText className="h-4 w-4" />,
    description: 'Full trail',
  },
  {
    id: 'gate',
    label: 'Trust Gate',
    icon: <ShieldCheck className="h-4 w-4" />,
    description: 'Gate decisions',
  },
]

interface SidebarProps {
  active: ActivePanel
  onChange: (panel: ActivePanel) => void
  evidenceCount: number
  gateCount: number
}

export function Sidebar({ active, onChange, evidenceCount, gateCount }: SidebarProps) {
  return (
    <aside className="flex w-16 shrink-0 flex-col items-center gap-1 border-r border-white/[0.06] bg-surface-200 py-4 lg:w-52 lg:items-stretch lg:px-2">
      {NAV_ITEMS.map((item) => {
        const isActive = item.id === active
        const badge =
          item.id === 'evidence' ? evidenceCount :
          item.id === 'gate' ? gateCount :
          null

        return (
          <button
            key={item.id}
            onClick={() => onChange(item.id)}
            className={cn(
              'group relative flex items-center gap-3 rounded-lg px-2 py-2.5 text-left transition-all duration-150',
              'lg:px-3',
              isActive
                ? 'bg-brand/10 text-brand'
                : 'text-slate-500 hover:bg-white/5 hover:text-slate-300',
            )}
          >
            {/* Active indicator bar */}
            {isActive && (
              <span className="absolute left-0 top-1/2 h-5 w-0.5 -translate-y-1/2 rounded-r-full bg-brand" />
            )}

            <span className="shrink-0">{item.icon}</span>

            <span className="hidden flex-1 lg:block">
              <span className="block text-sm font-medium">{item.label}</span>
              <span className="block text-xs opacity-50">{item.description}</span>
            </span>

            {badge !== null && badge > 0 && (
              <span className={cn(
                'hidden h-5 min-w-5 items-center justify-center rounded-full px-1 text-xs font-mono font-bold lg:flex',
                isActive ? 'bg-brand/20 text-brand' : 'bg-white/5 text-slate-500',
              )}>
                {badge}
              </span>
            )}
          </button>
        )
      })}
    </aside>
  )
}
