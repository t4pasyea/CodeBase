import { ShieldAlert, Activity, Wifi, WifiOff } from 'lucide-react'
import { Badge } from '../ui/Badge'
import type { HealthStatus, ScenarioStatus } from '../../api/types'

interface HeaderProps {
  health: HealthStatus | null
  backendOnline: boolean
  activeScenarioStatus: ScenarioStatus | null
  onOpenConfig: () => void
}

export function Header({ health, backendOnline, activeScenarioStatus, onOpenConfig }: HeaderProps) {
  return (
    <header className="flex h-14 shrink-0 items-center justify-between border-b border-white/[0.06] bg-surface-200/80 px-6 backdrop-blur-sm">
      {/* Logo */}
      <div className="flex items-center gap-3">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-brand/10 border border-brand/20">
          <ShieldAlert className="h-4 w-4 text-brand" />
        </div>
        <div>
          <span className="font-mono text-base font-bold tracking-widest text-white">
            SKEPTIC
          </span>
          <span className="ml-2 hidden text-xs text-slate-500 sm:inline">
            Agentic Cybersecurity AI
          </span>
        </div>
      </div>

      {/* Center status */}
      {activeScenarioStatus && activeScenarioStatus === 'running' && (
        <div className="hidden items-center gap-2 md:flex">
          <span className="h-2 w-2 animate-pulse rounded-full bg-brand" />
          <span className="font-mono text-xs text-brand">INVESTIGATION IN PROGRESS</span>
        </div>
      )}

      {/* Right controls */}
      <div className="flex items-center gap-3">
        {/* Backend connection */}
        <div className="hidden items-center gap-1.5 sm:flex">
          {backendOnline ? (
            <>
              <Wifi className="h-3.5 w-3.5 text-gate-act" />
              <span className="text-xs text-gate-act font-mono">CONNECTED</span>
            </>
          ) : (
            <>
              <WifiOff className="h-3.5 w-3.5 text-gate-escalate" />
              <span className="text-xs text-gate-escalate font-mono">OFFLINE</span>
            </>
          )}
        </div>

        {/* Fallback mode indicator */}
        {health && (
          <Badge variant={health.fallback_mode ? 'ghost' : 'brand'} dot>
            {health.fallback_mode ? 'FALLBACK' : 'LLM LIVE'}
          </Badge>
        )}

        {/* Config button */}
        <button
          onClick={onOpenConfig}
          className="flex items-center gap-1.5 rounded-lg border border-white/10 bg-white/5 px-3 py-1.5 text-xs text-slate-300 transition hover:border-brand/30 hover:text-brand"
        >
          <Activity className="h-3.5 w-3.5" />
          Config
        </button>
      </div>
    </header>
  )
}
