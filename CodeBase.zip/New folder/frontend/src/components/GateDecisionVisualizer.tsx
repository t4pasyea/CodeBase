import { ShieldCheck, ShieldAlert, ShieldX, ArrowRight } from 'lucide-react'
import { cn } from '../lib/utils'
import { Badge } from './ui/Badge'
import type { GateDecision, GateDecisionType } from '../api/types'

// ─── Decision config ──────────────────────────────────────────────────────────

const DECISION_CFG: Record<
  GateDecisionType,
  {
    icon: React.ReactNode
    label: string
    color: string
    bg: string
    border: string
    glow: string
    description: string
  }
> = {
  ACT: {
    icon: <ShieldCheck className="h-5 w-5" />,
    label: 'ACT',
    color: 'text-gate-act',
    bg: 'bg-gate-act/10',
    border: 'border-gate-act/30',
    glow: 'shadow-glow-act',
    description: 'Sufficient independent corroboration. Action authorized.',
  },
  CONTINUE: {
    icon: <ShieldAlert className="h-5 w-5" />,
    label: 'CONTINUE',
    color: 'text-gate-continue',
    bg: 'bg-gate-continue/10',
    border: 'border-gate-continue/30',
    glow: '',
    description: 'Insufficient evidence. Agent must continue investigating.',
  },
  ESCALATE: {
    icon: <ShieldX className="h-5 w-5" />,
    label: 'ESCALATE',
    color: 'text-gate-escalate',
    bg: 'bg-gate-escalate/10',
    border: 'border-gate-escalate/30',
    glow: 'shadow-glow-escalate',
    description: 'Automatic action blocked. Human analyst required.',
  },
}

// ─── Corroboration meter ──────────────────────────────────────────────────────

function CorroborationMeter({
  independent,
  required,
}: {
  independent: number
  required: number
}) {
  if (required === 0) return null
  const met = independent >= required

  return (
    <div className="space-y-1.5">
      <div className="flex items-center justify-between text-[10px] font-mono text-slate-500">
        <span>Independent sources</span>
        <span className={met ? 'text-gate-act' : 'text-gate-escalate'}>
          {independent}/{required} required
        </span>
      </div>
      <div className="flex gap-1">
        {Array.from({ length: required }).map((_, i) => (
          <div
            key={i}
            className={cn(
              'h-2 flex-1 rounded-full transition-all duration-500',
              i < independent ? 'bg-gate-act' : 'bg-white/10',
            )}
          />
        ))}
      </div>
    </div>
  )
}

// ─── Single decision card ─────────────────────────────────────────────────────

function DecisionCard({
  decision,
  index,
  total,
}: {
  decision: GateDecision
  index: number
  total: number
}) {
  const cfg = DECISION_CFG[decision.decision as GateDecisionType]

  return (
    <div
      className={cn(
        'relative rounded-xl border p-4 space-y-3 transition-all animate-slide-up',
        cfg.border,
        cfg.bg,
        decision.decision === 'ACT' || decision.decision === 'ESCALATE' ? cfg.glow : '',
      )}
      style={{ animationDelay: `${index * 60}ms` }}
    >
      {/* Sequence number */}
      <span className="absolute right-3 top-3 font-mono text-[10px] text-slate-600">
        #{index + 1} of {total}
      </span>

      {/* Header */}
      <div className="flex items-center gap-3">
        <div className={cn(
          'flex h-10 w-10 shrink-0 items-center justify-center rounded-xl',
          cfg.bg,
          cfg.color,
        )}>
          {cfg.icon}
        </div>
        <div>
          <div className="flex items-center gap-2">
            <span className={cn('font-mono text-base font-bold', cfg.color)}>
              {cfg.label}
            </span>
            <Badge
              variant={
                decision.decision === 'ACT'      ? 'act' :
                decision.decision === 'CONTINUE' ? 'continue' :
                'escalate'
              }
            >
              {decision.decision}
            </Badge>
          </div>
          <p className="text-xs text-slate-500">{cfg.description}</p>
        </div>
      </div>

      {/* Reason */}
      <div className="rounded-lg border border-white/5 bg-white/[0.02] px-3 py-2">
        <p className="text-[10px] font-mono text-slate-600 uppercase tracking-wider mb-1">
          Gate Reason
        </p>
        <p className="font-mono text-xs leading-relaxed text-slate-300">{decision.reason}</p>
      </div>

      {/* Corroboration meter */}
      <CorroborationMeter
        independent={decision.independent_source_count}
        required={decision.required_count}
      />
    </div>
  )
}

// ─── Flow diagram ─────────────────────────────────────────────────────────────

function GateFlowDiagram() {
  const steps = [
    { label: 'AI Proposes', color: 'text-actor-ai', bg: 'bg-actor-ai/10 border-actor-ai/20' },
    { label: 'Gate Evaluates', color: 'text-actor-gate', bg: 'bg-actor-gate/10 border-actor-gate/20' },
    { label: 'Decide', color: 'text-white', bg: 'bg-white/5 border-white/10' },
  ]
  const outcomes = [
    { label: 'ACT', color: 'text-gate-act', bg: 'bg-gate-act/10 border-gate-act/20' },
    { label: 'CONTINUE', color: 'text-gate-continue', bg: 'bg-gate-continue/10 border-gate-continue/20' },
    { label: 'ESCALATE', color: 'text-gate-escalate', bg: 'bg-gate-escalate/10 border-gate-escalate/20' },
  ]

  return (
    <div className="rounded-xl border border-white/[0.06] bg-surface-200 p-4 space-y-3">
      <p className="text-xs font-medium text-slate-400 uppercase tracking-wider">Trust Gate Logic</p>

      {/* Main flow */}
      <div className="flex items-center gap-2 flex-wrap">
        {steps.map((step, i) => (
          <div key={i} className="flex items-center gap-2">
            <div className={cn(
              'rounded-lg border px-3 py-1.5 font-mono text-xs font-medium',
              step.bg, step.color,
            )}>
              {step.label}
            </div>
            {i < steps.length - 1 && <ArrowRight className="h-3 w-3 text-slate-600 shrink-0" />}
          </div>
        ))}
      </div>

      {/* Outcome branches */}
      <div className="flex flex-wrap gap-2 pl-2">
        {outcomes.map((o, i) => (
          <div key={i} className={cn(
            'rounded-md border px-2.5 py-1 font-mono text-xs font-bold',
            o.bg, o.color,
          )}>
            {o.label}
          </div>
        ))}
      </div>

      {/* Rules */}
      <div className="space-y-1 text-[10px] font-mono text-slate-600">
        <p><span className="text-slate-500">→</span> Gate ignores AI confidence, justification, and semantic content</p>
        <p><span className="text-slate-500">→</span> Only structural provenance metadata is evaluated</p>
        <p><span className="text-slate-500">→</span> High-blast actions require ≥2 independent sources</p>
        <p><span className="text-slate-500">→</span> Low-blast actions require ≥1 independent source</p>
        <p><span className="text-slate-500">→</span> Irreversible actions are never auto-authorized</p>
      </div>
    </div>
  )
}

// ─── Main component ───────────────────────────────────────────────────────────

export function GateDecisionVisualizer({ decisions }: { decisions: GateDecision[] }) {
  const counts = {
    ACT:      decisions.filter((d) => d.decision === 'ACT').length,
    CONTINUE: decisions.filter((d) => d.decision === 'CONTINUE').length,
    ESCALATE: decisions.filter((d) => d.decision === 'ESCALATE').length,
  }

  return (
    <div className="flex flex-col gap-4">
      {/* Page header */}
      <div className="space-y-1">
        <h2 className="text-lg font-semibold text-white">Trust Gate</h2>
        <p className="text-sm text-slate-500">
          Pure deterministic code. No AI, no confidence values. The security boundary of the system.
        </p>
      </div>

      {/* Summary counts */}
      <div className="grid grid-cols-3 gap-3">
        {(Object.entries(counts) as [GateDecisionType, number][]).map(([decision, count]) => {
          const cfg = DECISION_CFG[decision]
          return (
            <div
              key={decision}
              className={cn(
                'flex flex-col items-center gap-1 rounded-xl border py-4',
                cfg.border, cfg.bg,
              )}
            >
              <span className={cn('', cfg.color)}>{cfg.icon}</span>
              <span className={cn('font-mono text-2xl font-bold', cfg.color)}>{count}</span>
              <span className={cn('font-mono text-xs', cfg.color)}>{decision}</span>
            </div>
          )
        })}
      </div>

      {/* Flow diagram */}
      <GateFlowDiagram />

      {/* Decision list */}
      {decisions.length === 0 ? (
        <div className="flex flex-col items-center gap-3 rounded-xl border border-dashed border-white/10 py-16 text-center">
          <ShieldCheck className="h-8 w-8 text-slate-700" />
          <p className="text-sm text-slate-500">No gate evaluations yet</p>
        </div>
      ) : (
        <div className="space-y-3">
          <p className="text-xs font-medium text-slate-500 uppercase tracking-wider">
            Decision History ({decisions.length})
          </p>
          {decisions.map((d, i) => (
            <DecisionCard key={i} decision={d} index={i} total={decisions.length} />
          ))}
        </div>
      )}
    </div>
  )
}
