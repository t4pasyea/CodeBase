import { Play, RotateCcw, AlertTriangle, Zap, Eye, ShieldOff } from 'lucide-react'
import { cn } from '../lib/utils'
import { Badge } from './ui/Badge'
import { Button } from './ui/Button'
import type { ScenarioInfo, InvestigationState, ScenarioStatus } from '../api/types'

interface ScenarioSelectorProps {
  scenarios: ScenarioInfo[]
  activeScenarioId: string | null
  states: Record<string, InvestigationState>
  loadingId: string | null
  onRun: (id: string) => void
  onReset: (id: string) => void
  onSelect: (id: string) => void
}

const SCENARIO_ICONS: Record<string, React.ReactNode> = {
  'scenario-a': <ShieldOff className="h-5 w-5" />,
  'scenario-b': <Eye className="h-5 w-5" />,
}

const SCENARIO_ACCENT: Record<string, string> = {
  'scenario-a': 'border-threat-high/20 hover:border-threat-high/40',
  'scenario-b': 'border-hyp-active/20 hover:border-hyp-active/40',
}

const SCENARIO_ICON_BG: Record<string, string> = {
  'scenario-a': 'bg-threat-high/10 text-threat-high',
  'scenario-b': 'bg-hyp-active/10 text-hyp-active',
}

function statusVariant(s: ScenarioStatus) {
  if (s === 'running')   return 'running'
  if (s === 'completed') return 'completed'
  if (s === 'escalated') return 'escalate'
  if (s === 'error')     return 'error'
  return 'idle'
}

function statusLabel(s: ScenarioStatus) {
  return s.toUpperCase()
}

export function ScenarioSelector({
  scenarios,
  activeScenarioId,
  states,
  loadingId,
  onRun,
  onReset,
  onSelect,
}: ScenarioSelectorProps) {
  return (
    <div className="flex flex-col gap-4">
      {/* Page header */}
      <div className="space-y-1">
        <h2 className="text-lg font-semibold text-white">Threat Scenarios</h2>
        <p className="text-sm text-slate-500">
          Select a scenario to run an automated investigation. The AI agent will collect evidence,
          form hypotheses, and propose actions — the deterministic Trust Gate decides what executes.
        </p>
      </div>

      {/* Architecture note */}
      <div className="flex items-start gap-3 rounded-xl border border-brand/20 bg-brand/5 p-4">
        <Zap className="mt-0.5 h-4 w-4 shrink-0 text-brand" />
        <div className="space-y-1 text-xs text-slate-400 leading-relaxed">
          <p className="font-medium text-brand">How it works</p>
          <p>
            The AI investigates and proposes actions, but <span className="text-white font-medium">never executes them</span>.
            The <span className="text-actor-gate font-medium">Trust Gate</span> — pure deterministic code with no AI input —
            evaluates evidence provenance and decides: <span className="text-gate-act font-medium">ACT</span>,&nbsp;
            <span className="text-gate-continue font-medium">CONTINUE</span>, or{' '}
            <span className="text-gate-escalate font-medium">ESCALATE</span>.
          </p>
        </div>
      </div>

      {/* Scenario cards */}
      <div className="grid gap-4 lg:grid-cols-2">
        {scenarios.map((s) => {
          const state   = states[s.id]
          const status  = state?.status ?? 'idle'
          const isActive   = activeScenarioId === s.id
          const isRunning  = status === 'running'
          const isLoading  = loadingId === s.id
          const isDone     = status === 'completed' || status === 'escalated'
          const accent     = SCENARIO_ACCENT[s.id] ?? 'border-white/10'
          const iconBg     = SCENARIO_ICON_BG[s.id] ?? 'bg-white/5 text-slate-400'

          return (
            <button
              key={s.id}
              onClick={() => onSelect(s.id)}
              className={cn(
                'group relative flex flex-col gap-4 rounded-xl border bg-surface-200 p-5 text-left transition-all duration-200',
                accent,
                isActive && 'ring-1 ring-brand/30',
              )}
            >
              {/* Active dot */}
              {isActive && (
                <span className="absolute right-4 top-4 h-2 w-2 rounded-full bg-brand" />
              )}

              {/* Card header */}
              <div className="flex items-start gap-3">
                <div className={cn('flex h-10 w-10 shrink-0 items-center justify-center rounded-xl', iconBg)}>
                  {SCENARIO_ICONS[s.id] ?? <AlertTriangle className="h-5 w-5" />}
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="font-semibold text-white">{s.name}</p>
                    <Badge variant={statusVariant(status)} dot>
                      {statusLabel(status)}
                    </Badge>
                    {s.force_lie && (
                      <Badge variant="escalate">LYING API</Badge>
                    )}
                  </div>
                  <p className="mt-1 text-xs leading-relaxed text-slate-500">{s.description}</p>
                </div>
              </div>

              {/* Expected outcome */}
              <div className="rounded-lg border border-white/5 bg-white/[0.03] px-3 py-2">
                <p className="text-xs text-slate-500">
                  <span className="font-medium text-slate-400">Expected outcome: </span>
                  {s.expected_outcome}
                </p>
              </div>

              {/* Progress snapshot (if started) */}
              {state && status !== 'idle' && (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs text-slate-500">
                    <span>Investigation progress</span>
                    <span className="font-mono text-slate-400">
                      Step {state.step_count}/{state.max_steps}
                    </span>
                  </div>
                  <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/5">
                    <div
                      className={cn(
                        'h-full rounded-full transition-all duration-700',
                        status === 'escalated' ? 'bg-gate-escalate' :
                        status === 'completed' ? 'bg-gate-act' :
                        'bg-brand animate-pulse-slow',
                      )}
                      style={{ width: `${(state.step_count / state.max_steps) * 100}%` }}
                    />
                  </div>
                  {state.final_outcome && (
                    <p className="text-xs italic text-slate-500 line-clamp-2">{state.final_outcome}</p>
                  )}
                </div>
              )}

              {/* Actions */}
              <div
                className="flex items-center gap-2"
                onClick={(e) => e.stopPropagation()}
              >
                <Button
                  variant="primary"
                  size="sm"
                  icon={<Play className="h-3.5 w-3.5" />}
                  loading={isLoading}
                  disabled={isRunning || isLoading}
                  onClick={() => onRun(s.id)}
                  className="flex-1"
                >
                  {isRunning ? 'Running…' : isDone ? 'Run Again' : 'Run Scenario'}
                </Button>
                {isDone && (
                  <Button
                    variant="outline"
                    size="sm"
                    icon={<RotateCcw className="h-3.5 w-3.5" />}
                    onClick={() => onReset(s.id)}
                  >
                    Reset
                  </Button>
                )}
              </div>
            </button>
          )
        })}
      </div>

      {/* Empty state */}
      {scenarios.length === 0 && (
        <div className="flex flex-col items-center gap-3 rounded-xl border border-dashed border-white/10 py-16 text-center">
          <AlertTriangle className="h-8 w-8 text-slate-600" />
          <p className="text-sm text-slate-500">No scenarios available — is the backend running?</p>
        </div>
      )}
    </div>
  )
}
