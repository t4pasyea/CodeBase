import { cn } from '../../lib/utils'

type Variant =
  | 'brand' | 'act' | 'continue' | 'escalate'
  | 'data' | 'instruction'
  | 'active' | 'revised' | 'rejected'
  | 'ai' | 'gate' | 'action' | 'verification' | 'orchestrator' | 'classifier'
  | 'idle' | 'running' | 'completed' | 'error'
  | 'ghost'

const VARIANT_CLASSES: Record<Variant, string> = {
  brand:        'bg-brand/10 text-brand border-brand/30',
  act:          'bg-gate-act/10 text-gate-act border-gate-act/30',
  continue:     'bg-gate-continue/10 text-gate-continue border-gate-continue/30',
  escalate:     'bg-gate-escalate/10 text-gate-escalate border-gate-escalate/30',
  data:         'bg-evidence-data/10 text-evidence-data border-evidence-data/30',
  instruction:  'bg-evidence-instruction/10 text-evidence-instruction border-evidence-instruction/30',
  active:       'bg-hyp-active/10 text-hyp-active border-hyp-active/30',
  revised:      'bg-hyp-revised/10 text-hyp-revised border-hyp-revised/30',
  rejected:     'bg-hyp-rejected/10 text-hyp-rejected border-hyp-rejected/30',
  ai:           'bg-actor-ai/10 text-actor-ai border-actor-ai/30',
  gate:         'bg-actor-gate/10 text-actor-gate border-actor-gate/30',
  action:       'bg-actor-action/10 text-actor-action border-actor-action/30',
  verification: 'bg-actor-verification/10 text-actor-verification border-actor-verification/30',
  orchestrator: 'bg-actor-orchestrator/10 text-actor-orchestrator border-actor-orchestrator/30',
  classifier:   'bg-actor-classifier/10 text-actor-classifier border-actor-classifier/30',
  idle:         'bg-surface-100/40 text-slate-400 border-slate-600/30',
  running:      'bg-brand/10 text-brand border-brand/30',
  completed:    'bg-gate-act/10 text-gate-act border-gate-act/30',
  error:        'bg-gate-escalate/10 text-gate-escalate border-gate-escalate/30',
  ghost:        'bg-white/5 text-slate-400 border-white/10',
}

interface BadgeProps {
  variant?: Variant
  children: React.ReactNode
  className?: string
  dot?: boolean
}

export function Badge({ variant = 'ghost', children, className, dot }: BadgeProps) {
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1.5 rounded-md border px-2 py-0.5 text-xs font-mono font-medium',
        VARIANT_CLASSES[variant],
        className,
      )}
    >
      {dot && (
        <span className="inline-block h-1.5 w-1.5 rounded-full bg-current opacity-80" />
      )}
      {children}
    </span>
  )
}
