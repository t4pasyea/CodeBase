import { cn } from '../../lib/utils'

interface PanelProps {
  title?: string
  subtitle?: string
  icon?: React.ReactNode
  children: React.ReactNode
  className?: string
  headerRight?: React.ReactNode
  noPad?: boolean
}

export function Panel({ title, subtitle, icon, children, className, headerRight, noPad }: PanelProps) {
  return (
    <div
      className={cn(
        'rounded-xl border border-white/[0.06] bg-surface-200 shadow-panel flex flex-col',
        className,
      )}
    >
      {(title || headerRight) && (
        <div className="flex items-center justify-between gap-3 border-b border-white/[0.06] px-4 py-3">
          <div className="flex items-center gap-2 min-w-0">
            {icon && (
              <span className="shrink-0 text-brand">{icon}</span>
            )}
            <div className="min-w-0">
              {title && (
                <p className="text-sm font-semibold text-white truncate">{title}</p>
              )}
              {subtitle && (
                <p className="text-xs text-slate-500 truncate">{subtitle}</p>
              )}
            </div>
          </div>
          {headerRight && (
            <div className="shrink-0">{headerRight}</div>
          )}
        </div>
      )}
      <div className={cn('flex-1 min-h-0', !noPad && 'p-4')}>
        {children}
      </div>
    </div>
  )
}
