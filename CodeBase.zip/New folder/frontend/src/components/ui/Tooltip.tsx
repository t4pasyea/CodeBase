import { useState } from 'react'
import { cn } from '../../lib/utils'

interface TooltipProps {
  content: React.ReactNode
  children: React.ReactNode
  className?: string
}

export function Tooltip({ content, children, className }: TooltipProps) {
  const [visible, setVisible] = useState(false)

  return (
    <span
      className="relative inline-flex"
      onMouseEnter={() => setVisible(true)}
      onMouseLeave={() => setVisible(false)}
      onFocus={() => setVisible(true)}
      onBlur={() => setVisible(false)}
    >
      {children}
      {visible && (
        <span
          className={cn(
            'pointer-events-none absolute bottom-full left-1/2 z-50 mb-2 -translate-x-1/2',
            'max-w-xs rounded-lg border border-white/10 bg-surface-100 px-3 py-2',
            'text-xs text-slate-200 shadow-lg whitespace-normal',
            'animate-fade-in',
            className,
          )}
        >
          {content}
        </span>
      )}
    </span>
  )
}
