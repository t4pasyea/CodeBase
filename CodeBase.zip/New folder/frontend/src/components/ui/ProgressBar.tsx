import { cn } from '../../lib/utils'

interface ProgressBarProps {
  value: number   // 0-100
  max?: number
  color?: 'brand' | 'act' | 'escalate' | 'continue'
  label?: string
  showValue?: boolean
  className?: string
  animated?: boolean
}

const COLOR_CLASSES = {
  brand:    'bg-brand',
  act:      'bg-gate-act',
  escalate: 'bg-gate-escalate',
  continue: 'bg-gate-continue',
}

export function ProgressBar({
  value,
  max = 100,
  color = 'brand',
  label,
  showValue,
  className,
  animated,
}: ProgressBarProps) {
  const pct = Math.min(100, Math.max(0, (value / max) * 100))

  return (
    <div className={cn('space-y-1', className)}>
      {(label || showValue) && (
        <div className="flex items-center justify-between text-xs text-slate-400">
          {label && <span>{label}</span>}
          {showValue && (
            <span className="font-mono text-slate-300">
              {value}/{max}
            </span>
          )}
        </div>
      )}
      <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/5">
        <div
          className={cn(
            'h-full rounded-full transition-all duration-500',
            COLOR_CLASSES[color],
            animated && 'animate-pulse-slow',
          )}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  )
}
