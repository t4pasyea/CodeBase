import { BrainCircuit, CheckCircle2, RefreshCw, XCircle, ChevronDown, ChevronUp } from 'lucide-react'
import { useState } from 'react'
import { cn } from '../lib/utils'
import { Badge } from './ui/Badge'
import type { Hypothesis, HypothesisStatus } from '../api/types'

// ─── Status config ────────────────────────────────────────────────────────────

const STATUS_CFG: Record<
  HypothesisStatus,
  { icon: React.ReactNode; label: string; border: string; bg: string; text: string }
> = {
  active: {
    icon: <BrainCircuit className="h-4 w-4" />,
    label: 'ACTIVE',
    border: 'border-hyp-active/20',
    bg:    'bg-hyp-active/5',
    text:  'text-hyp-active',
  },
  revised: {
    icon: <RefreshCw className="h-4 w-4" />,
    label: 'REVISED',
    border: 'border-hyp-revised/20',
    bg:    'bg-hyp-revised/5',
    text:  'text-hyp-revised',
  },
  rejected: {
    icon: <XCircle className="h-4 w-4" />,
    label: 'REJECTED',
    border: 'border-hyp-rejected/20',
    bg:    'bg-white/[0.02]',
    text:  'text-hyp-rejected',
  },
}

// ─── Single hypothesis card ───────────────────────────────────────────────────

function HypothesisCard({ h, index }: { h: Hypothesis; index: number }) {
  const [expanded, setExpanded] = useState(h.status === 'active')
  const cfg = STATUS_CFG[h.status as HypothesisStatus]

  return (
    <div
      className={cn(
        'rounded-xl border transition-all duration-200 animate-slide-up',
        cfg.border,
        cfg.bg,
        h.status === 'rejected' && 'opacity-60',
      )}
      style={{ animationDelay: `${index * 50}ms` }}
    >
      <button
        className="flex w-full items-start gap-3 p-4 text-left"
        onClick={() => setExpanded((v) => !v)}
      >
        {/* Status icon */}
        <div className={cn(
          'mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-white/5',
          cfg.text,
        )}>
          {cfg.icon}
        </div>

        <div className="flex-1 min-w-0 space-y-1.5">
          {/* Status + id */}
          <div className="flex items-center gap-2 flex-wrap">
            <Badge variant={h.status as 'active' | 'revised' | 'rejected'}>
              {cfg.label}
            </Badge>
            <span className="font-mono text-[10px] text-slate-600">{h.id}</span>
          </div>
          {/* Description */}
          <p className={cn(
            'text-sm leading-relaxed',
            h.status === 'rejected' ? 'line-through text-slate-600' : 'text-slate-300',
          )}>
            {h.description}
          </p>
          {/* Evidence chips (collapsed preview) */}
          {!expanded && h.supporting_evidence_ids.length > 0 && (
            <div className="flex flex-wrap gap-1">
              {h.supporting_evidence_ids.slice(0, 4).map((id) => (
                <span
                  key={id}
                  className="rounded border border-white/10 px-1.5 py-0.5 font-mono text-[10px] text-slate-500"
                >
                  {id}
                </span>
              ))}
              {h.supporting_evidence_ids.length > 4 && (
                <span className="text-[10px] text-slate-600">
                  +{h.supporting_evidence_ids.length - 4} more
                </span>
              )}
            </div>
          )}
        </div>

        <span className="mt-0.5 shrink-0 text-slate-600">
          {expanded ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
        </span>
      </button>

      {/* Expanded detail */}
      {expanded && (
        <div className="border-t border-white/[0.06] px-4 pb-4 pt-3 space-y-3 animate-fade-in">
          <div className="space-y-1.5">
            <p className="text-[10px] font-mono text-slate-600 uppercase tracking-wider">
              Supporting Evidence ({h.supporting_evidence_ids.length} items)
            </p>
            {h.supporting_evidence_ids.length === 0 ? (
              <p className="text-xs text-slate-600 italic">No evidence linked</p>
            ) : (
              <div className="flex flex-wrap gap-1.5">
                {h.supporting_evidence_ids.map((id) => (
                  <span
                    key={id}
                    className="rounded-md border border-evidence-data/20 bg-evidence-data/10 px-2 py-1 font-mono text-xs text-evidence-data"
                  >
                    {id}
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  )
}

// ─── Main component ───────────────────────────────────────────────────────────

export function HypothesisTracker({ hypotheses }: { hypotheses: Hypothesis[] }) {
  const active   = hypotheses.filter((h) => h.status === 'active')
  const revised  = hypotheses.filter((h) => h.status === 'revised')
  const rejected = hypotheses.filter((h) => h.status === 'rejected')

  return (
    <div className="flex flex-col gap-4">
      {/* Page header */}
      <div className="space-y-1">
        <h2 className="text-lg font-semibold text-white">AI Hypotheses</h2>
        <p className="text-sm text-slate-500">
          The AI agent forms and updates hypotheses as it gathers evidence.
          Rejected hypotheses are kept for transparency.
        </p>
      </div>

      {/* Summary badges */}
      <div className="flex flex-wrap gap-2">
        <Badge variant="active" dot>{active.length} active</Badge>
        <Badge variant="revised" dot>{revised.length} revised</Badge>
        <Badge variant="rejected" dot>{rejected.length} rejected</Badge>
      </div>

      {/* Sections */}
      {hypotheses.length === 0 ? (
        <div className="flex flex-col items-center gap-3 rounded-xl border border-dashed border-white/10 py-16 text-center">
          <BrainCircuit className="h-8 w-8 text-slate-700" />
          <p className="text-sm text-slate-500">No hypotheses yet — investigation hasn't started</p>
        </div>
      ) : (
        <div className="space-y-6">
          {active.length > 0 && (
            <section className="space-y-2">
              <div className="flex items-center gap-2">
                <BrainCircuit className="h-4 w-4 text-hyp-active" />
                <p className="text-xs font-semibold uppercase tracking-wider text-hyp-active">Active</p>
              </div>
              {active.map((h, i) => <HypothesisCard key={h.id} h={h} index={i} />)}
            </section>
          )}

          {revised.length > 0 && (
            <section className="space-y-2">
              <div className="flex items-center gap-2">
                <RefreshCw className="h-4 w-4 text-hyp-revised" />
                <p className="text-xs font-semibold uppercase tracking-wider text-hyp-revised">Revised</p>
              </div>
              {revised.map((h, i) => <HypothesisCard key={h.id} h={h} index={i} />)}
            </section>
          )}

          {rejected.length > 0 && (
            <section className="space-y-2">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-hyp-rejected" />
                <p className="text-xs font-semibold uppercase tracking-wider text-hyp-rejected">Rejected</p>
              </div>
              {rejected.map((h, i) => <HypothesisCard key={h.id} h={h} index={i} />)}
            </section>
          )}
        </div>
      )}
    </div>
  )
}
