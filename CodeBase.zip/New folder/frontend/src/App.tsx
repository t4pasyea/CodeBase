import { useState } from 'react'
import { Header } from './components/layout/Header'
import { Sidebar, type ActivePanel } from './components/layout/Sidebar'
import { ScenarioSelector } from './components/ScenarioSelector'
import { InvestigationDashboard } from './components/InvestigationDashboard'
import { EvidenceStore } from './components/EvidenceStore'
import { HypothesisTracker } from './components/HypothesisTracker'
import { AuditTimeline } from './components/AuditTimeline'
import { GateDecisionVisualizer } from './components/GateDecisionVisualizer'
import { ConfigPanel } from './components/ConfigPanel'
import { useInvestigation } from './hooks/useInvestigation'
import { AlertCircle, WifiOff } from 'lucide-react'

export default function App() {
  const [activePanel, setActivePanel]   = useState<ActivePanel>('scenarios')
  const [configOpen, setConfigOpen]     = useState(false)

  const {
    health,
    backendOnline,
    scenarios,
    states,
    activeScenarioId,
    loadingId,
    error,
    handleRun,
    handleReset,
    handleSelect,
    refreshConfig,
  } = useInvestigation()

  // Derive current state for the active scenario
  const activeState = activeScenarioId ? states[activeScenarioId] ?? null : null
  const activeStatus = activeState?.status ?? null

  // Counts for sidebar badges
  const evidenceCount = activeState?.evidence_store.length ?? 0
  const gateCount     = activeState?.gate_decisions.length ?? 0

  // Navigate to dashboard when a scenario is selected and running
  function handleRunAndNavigate(id: string) {
    handleRun(id)
    setActivePanel('dashboard')
  }

  return (
    <div className="flex h-screen flex-col overflow-hidden bg-surface-300">
      <Header
        health={health}
        backendOnline={backendOnline}
        activeScenarioStatus={activeStatus}
        onOpenConfig={() => setConfigOpen(true)}
      />

      <div className="flex flex-1 overflow-hidden">
        <Sidebar
          active={activePanel}
          onChange={setActivePanel}
          evidenceCount={evidenceCount}
          gateCount={gateCount}
        />

        {/* Main content area */}
        <main className="flex-1 overflow-y-auto p-4 lg:p-6">
          {/* Backend offline banner */}
          {!backendOnline && (
            <div className="mb-4 flex items-center gap-3 rounded-xl border border-gate-escalate/20 bg-gate-escalate/10 px-4 py-3 text-sm text-gate-escalate animate-fade-in">
              <WifiOff className="h-4 w-4 shrink-0" />
              <span>
                <span className="font-semibold">Backend offline.</span>{' '}
                Start the FastAPI server with{' '}
                <code className="rounded bg-white/10 px-1 font-mono text-xs">
                  uvicorn main:app --reload
                </code>{' '}
                in the <code className="rounded bg-white/10 px-1 font-mono text-xs">backend/</code> directory.
              </span>
            </div>
          )}

          {/* API error */}
          {error && backendOnline && (
            <div className="mb-4 flex items-center gap-3 rounded-xl border border-gate-continue/20 bg-gate-continue/10 px-4 py-3 text-sm text-gate-continue animate-fade-in">
              <AlertCircle className="h-4 w-4 shrink-0" />
              {error}
            </div>
          )}

          {/* Panel router */}
          {activePanel === 'scenarios' && (
            <ScenarioSelector
              scenarios={scenarios}
              activeScenarioId={activeScenarioId}
              states={states}
              loadingId={loadingId}
              onRun={handleRunAndNavigate}
              onReset={handleReset}
              onSelect={handleSelect}
            />
          )}

          {activePanel === 'dashboard' && (
            <InvestigationDashboard
              state={activeState}
              scenarioName={activeState?.scenario_name ?? (activeScenarioId ?? '')}
            />
          )}

          {activePanel === 'evidence' && (
            <EvidenceStore items={activeState?.evidence_store ?? []} />
          )}

          {activePanel === 'hypotheses' && (
            <HypothesisTracker hypotheses={activeState?.hypotheses ?? []} />
          )}

          {activePanel === 'audit' && (
            <AuditTimeline entries={activeState?.audit_log ?? []} />
          )}

          {activePanel === 'gate' && (
            <GateDecisionVisualizer decisions={activeState?.gate_decisions ?? []} />
          )}
        </main>
      </div>

      {/* Config modal */}
      {configOpen && (
        <ConfigPanel
          health={health}
          onClose={() => setConfigOpen(false)}
          onUpdated={() => {
            refreshConfig()
            setConfigOpen(false)
          }}
        />
      )}
    </div>
  )
}
