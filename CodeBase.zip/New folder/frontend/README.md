# SKEPTIC Frontend

React + Vite + TypeScript + Tailwind CSS UI for the **SKEPTIC** Agentic AI Cybersecurity Assistant.

## Quick Start

### Prerequisites
- [Node.js ≥ 18](https://nodejs.org/)
- Backend running: `cd backend && uvicorn main:app --reload` (default port 8000)

### Install & Run

```bash
cd frontend
npm install
npm run dev
```

Open [http://localhost:5173](http://localhost:5173)

The Vite dev server proxies `/api` → `http://localhost:8000` automatically.

### Build for Production

```bash
npm run build
npm run preview   # serve the built output locally
```

## What the UI does

| Panel | Description |
|-------|-------------|
| **Scenarios** | Select Scenario A or B, start investigations, see progress |
| **Dashboard** | Live status, step budget meter, gate decision summary, source coverage |
| **Evidence** | Full evidence store with provenance metadata, classification tags, search & filter |
| **Hypotheses** | AI hypothesis tree — active / revised / rejected, with supporting evidence |
| **Audit Log** | Append-only timeline of every event, filterable by actor |
| **Trust Gate** | Visualizes every gate evaluation with corroboration meters |

### Config modal (top-right)
- Toggle fallback mode (pre-recorded responses / no API key required)
- Set max investigation steps
- Provide Gemini API key for live LLM mode

## Architecture note

The frontend is **display-only** — it never makes security decisions.
All logic (trust gate, classification, actions) lives in the backend.
The UI polls `GET /api/scenarios/{id}/state` every 1.5 s while an investigation is running.
